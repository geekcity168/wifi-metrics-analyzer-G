#!/bin/bash

# WiFi Metrics Analyzer Launcher Script
# This script helps launch the application with proper environment setup

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Application info
APP_NAME="WiFi Metrics Analyzer"
APP_VERSION="2.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$SCRIPT_DIR/venv"
PYTHON_SCRIPT="$SCRIPT_DIR/src/main.py"

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║        WiFi Metrics Analyzer v2.0     ║${NC}"
echo -e "${BLUE}║       Advanced WiFi Monitoring Tool    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"
echo ""

# Function to check if virtual environment exists
check_venv() {
    if [ ! -d "$VENV_DIR" ]; then
        echo -e "${RED}❌ Virtual environment not found at $VENV_DIR${NC}"
        echo -e "${YELLOW}💡 Please run the installation first:${NC}"
        echo -e "   python3 -m venv venv"
        echo -e "   source venv/bin/activate"
        echo -e "   pip install -r requirements.txt"
        exit 1
    fi
}

# Function to check if dependencies are installed
check_dependencies() {
    source "$VENV_DIR/bin/activate"
    
    local missing_deps=()
    
    # Check for required Python packages
    for package in psutil scapy netifaces matplotlib plyer numpy speedtest-cli; do
        if ! python -c "import $package" 2>/dev/null; then
            missing_deps+=("$package")
        fi
    done
    
    if [ ${#missing_deps[@]} -ne 0 ]; then
        echo -e "${RED}❌ Missing dependencies: ${missing_deps[*]}${NC}"
        echo -e "${YELLOW}💡 Installing missing dependencies...${NC}"
        pip install -r requirements.txt
        if [ $? -ne 0 ]; then
            echo -e "${RED}❌ Failed to install dependencies${NC}"
            exit 1
        fi
    fi
}

# Function to check system tools
check_system_tools() {
    local missing_tools=()
    
    # Check for system tools
    for tool in iwconfig ping ip; do
        if ! command -v "$tool" &> /dev/null; then
            missing_tools+=("$tool")
        fi
    done
    
    if [ ${#missing_tools[@]} -ne 0 ]; then
        echo -e "${YELLOW}⚠️  Missing system tools: ${missing_tools[*]}${NC}"
        echo -e "${YELLOW}💡 Install them with:${NC}"
        echo -e "   sudo apt install wireless-tools net-tools iputils-ping"
        echo ""
    fi
}

# Function to check permissions
check_permissions() {
    if [ "$EUID" -eq 0 ]; then
        echo -e "${GREEN}✅ Running with root privileges (full functionality)${NC}"
        return 0
    else
        echo -e "${YELLOW}⚠️  Running without root privileges${NC}"
        echo -e "${YELLOW}   Some features may be limited (device scanning, accurate signal monitoring)${NC}"
        echo -e "${BLUE}💡 For full functionality, run with: sudo $0${NC}"
        echo ""
        
        # Ask user if they want to continue or restart with sudo
        read -p "Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo -e "${BLUE}🔄 Restarting with sudo...${NC}"
            exec sudo "$0" "$@"
        fi
    fi
}

# Function to display system info
show_system_info() {
    echo -e "${BLUE}📊 System Information:${NC}"
    echo -e "   OS: $(uname -s) $(uname -r)"
    echo -e "   Architecture: $(uname -m)"
    echo -e "   Python: $(python3 --version 2>/dev/null || echo 'Not found')"
    
    # Show WiFi interfaces
    if command -v iwconfig &> /dev/null; then
        local interfaces=$(iwconfig 2>/dev/null | grep -o '^[a-zA-Z0-9]*' | head -3)
        if [ -n "$interfaces" ]; then
            echo -e "   WiFi Interfaces: $(echo $interfaces | tr '\n' ' ')"
        else
            echo -e "   WiFi Interfaces: None detected"
        fi
    fi
    echo ""
}

# Function to run the application
run_application() {
    echo -e "${GREEN}🚀 Starting $APP_NAME...${NC}"
    echo -e "${BLUE}📝 Logs will be saved to: ~/.wifi-metrics-analyzer.log${NC}"
    echo -e "${BLUE}⌨️  Keyboard shortcuts: F5 (refresh), F11 (fullscreen), Ctrl+Q (quit)${NC}"
    echo ""
    
    # Activate virtual environment and run
    source "$VENV_DIR/bin/activate"
    
    # Check if we should run with GUI or CLI
    if [[ "$1" == "--cli" ]] || [[ "$1" == "--no-gui" ]]; then
        echo -e "${BLUE}🖥️  Running in CLI mode...${NC}"
        python "$PYTHON_SCRIPT" --no-gui "${@:2}"
    else
        echo -e "${BLUE}🖥️  Launching GUI...${NC}"
        python "$PYTHON_SCRIPT" "$@"
    fi
}

# Function to show usage
show_usage() {
    echo -e "${BLUE}Usage: $0 [OPTIONS]${NC}"
    echo ""
    echo -e "${YELLOW}Options:${NC}"
    echo -e "  --help              Show this help message"
    echo -e "  --cli, --no-gui     Run in command-line mode"
    echo -e "  --debug             Enable debug logging"
    echo -e "  --check             Check system requirements only"
    echo -e "  -i INTERFACE        Specify WiFi interface"
    echo ""
    echo -e "${YELLOW}Examples:${NC}"
    echo -e "  $0                  # Start with GUI"
    echo -e "  $0 --cli            # Start in CLI mode"
    echo -e "  $0 --debug          # Start with debug logging"
    echo -e "  sudo $0             # Start with root privileges"
    echo -e "  $0 -i wlan0         # Use specific interface"
}

# Function to check system requirements
check_system_requirements() {
    echo -e "${BLUE}🔍 Checking system requirements...${NC}"
    echo ""
    
    # Check Python version
    if command -v python3 &> /dev/null; then
        local python_version=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
        local python_major=$(echo $python_version | cut -d. -f1)
        local python_minor=$(echo $python_version | cut -d. -f2)
        
        if [ "$python_major" -gt 3 ] || ([ "$python_major" -eq 3 ] && [ "$python_minor" -ge 7 ]); then
            echo -e "${GREEN}✅ Python $python_version (requirement: 3.7+)${NC}"
        else
            echo -e "${RED}❌ Python $python_version (requirement: 3.7+)${NC}"
            return 1
        fi
    else
        echo -e "${RED}❌ Python 3 not found${NC}"
        return 1
    fi
    
    # Check virtual environment
    check_venv
    echo -e "${GREEN}✅ Virtual environment found${NC}"
    
    # Check dependencies
    check_dependencies
    echo -e "${GREEN}✅ Python dependencies installed${NC}"
    
    # Check system tools
    check_system_tools
    
    # Show system info
    show_system_info
    
    echo -e "${GREEN}✅ System requirements check complete${NC}"
}

# Main execution
main() {
    case "$1" in
        --help|-h)
            show_usage
            exit 0
            ;;
        --check)
            check_system_requirements
            exit 0
            ;;
        *)
            # Normal startup sequence
            check_venv
            check_dependencies
            check_system_tools
            check_permissions "$@"
            show_system_info
            run_application "$@"
            ;;
    esac
}

# Handle Ctrl+C gracefully
trap 'echo -e "\n${YELLOW}⚠️  Application interrupted by user${NC}"; exit 130' INT

# Run main function
main "$@"

