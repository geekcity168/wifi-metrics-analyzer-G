#!/usr/bin/env python3
"""
WiFi Metrics Analyzer GUI

This module implements a GUI dashboard for displaying WiFi metrics including
signal strength, speed test results, connected devices, and network usage.
"""

import os
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox, font
from typing import Dict, List, Any, Callable, Optional
import datetime
import logging
from collections import deque
import subprocess
import platform

import matplotlib
matplotlib.use('TkAgg')  # Set the backend before importing pyplot
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import numpy as np

# Import for desktop notifications
try:
    import plyer
    NOTIFICATIONS_AVAILABLE = True
except ImportError:
    NOTIFICATIONS_AVAILABLE = False
    print("plyer not available - desktop notifications disabled")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('WifiAnalyzerGUI')

# Modern UI Constants - Dark Theme with Glassmorphism
DARK_BG = "#0a0a0a"  # Deep black
LIGHT_BG = "#1a1a1a"  # Dark gray
CARD_BG = "#2a2a2a"   # Lighter gray for cards
ACCENT_COLOR = "#00d4ff"  # Cyan accent
ACCENT_HOVER = "#00a8cc"  # Darker cyan for hover
TEXT_COLOR = "#ffffff"    # Pure white text
TEXT_SECONDARY = "#b0b0b0"  # Light gray secondary text
ALERT_COLOR = "#ff4757"     # Red
SUCCESS_COLOR = "#2ed573"   # Green
WARNING_COLOR = "#ffa502"   # Orange
INFO_COLOR = "#3742fa"      # Blue
BORDER_COLOR = "#404040"    # Gray border
GRADIENT_START = "#1e3c72"  # Gradient start
GRADIENT_END = "#2a5298"    # Gradient end

# Font settings - Modern typography
FONT_FAMILY = "Segoe UI" if platform.system() == "Windows" else "Ubuntu" if platform.system() == "Linux" else "SF Pro Display"
LARGE_FONT_SIZE = 16
MEDIUM_FONT_SIZE = 14
SMALL_FONT_SIZE = 11
TITLE_FONT_SIZE = 20
HEADER_FONT_SIZE = 18

class WifiAnalyzerGUI:
    """
    GUI for the WiFi Metrics Analyzer.
    
    This class implements a tkinter-based dashboard for displaying
    WiFi metrics including signal strength, speed test results,
    connected devices, and network usage.
    """
    
    def __init__(self, analyzer):
        """
        Initialize the GUI.
        
        Args:
            analyzer: An instance of WifiAnalyzer from wifi_analyzer.py
        """
        self.analyzer = analyzer
        self.root = tk.Tk()
        self.root.title("WiFi Metrics Analyzer")
        self.root.geometry("1200x800")
        self.root.minsize(900, 600)
        self.root.configure(bg=DARK_BG)
        
        # Set icon (if available)
        try:
            icon_path = os.path.join(os.path.dirname(__file__), '../assets/icon.png')
            if os.path.exists(icon_path):
                icon = tk.PhotoImage(file=icon_path)
                self.root.iconphoto(True, icon)
        except Exception as e:
            logger.warning(f"Could not load icon: {e}")
        
        # Create custom styles
        self._create_styles()
        
        # Data storage for graphs
        self.signal_history = deque(maxlen=60)  # Store 60 data points for signal strength
        self.network_history = deque(maxlen=60)  # Store 60 data points for network usage
        self.time_labels = deque(maxlen=60)  # Time labels for x-axis
        
        # Status variables
        self.status_var = tk.StringVar(value="Ready")
        self.interface_var = tk.StringVar(value="No interface selected")
        self.essid_var = tk.StringVar(value="Not connected")
        self.signal_strength_var = tk.StringVar(value="N/A")
        self.signal_quality_var = tk.StringVar(value="0%")
        self.download_speed_var = tk.StringVar(value="N/A")
        self.upload_speed_var = tk.StringVar(value="N/A")
        self.ping_var = tk.StringVar(value="N/A")
        self.devices_count_var = tk.StringVar(value="0")
        self.network_usage_var = tk.StringVar(value="↓ 0 KB/s  ↑ 0 KB/s")
        
        # State tracking
        self.speed_test_running = False
        self.scanning_devices = False
        self.update_running = False
        self.last_network_stats = None
        self.last_network_time = time.time()
        
        # Notification settings
        self.notifications_enabled = True
        self.last_notification_time = 0
        self.notification_cooldown = 30  # Seconds between notifications
        self.signal_threshold_low = 30  # Percentage below which to show warning
        self.signal_threshold_critical = 15  # Percentage below which to show critical alert
        
        # Performance tracking
        self.connection_history = deque(maxlen=100)  # Track connection stability
        self.speed_history = deque(maxlen=20)  # Track speed test history
        
        # Selected interface
        self.selected_interface = tk.StringVar()
        if self.analyzer.wifi_interfaces:
            self.selected_interface.set(self.analyzer.wifi_interfaces[0])
        
        # Create main layout
        self._create_layout()
        
        # Start updates
        self._start_metrics_update()
    
    def _create_styles(self):
        """Create custom ttk styles for the application."""
        # Configure ttk styles
        style = ttk.Style()
        
        # Set the theme - 'clam' is a good base for customization
        style.theme_use('clam')
        
        # Configure common elements
        style.configure('TFrame', background=DARK_BG)
        style.configure('TLabel', background=DARK_BG, foreground=TEXT_COLOR, 
                       font=(FONT_FAMILY, MEDIUM_FONT_SIZE))
        style.configure('TButton', background=LIGHT_BG, foreground=TEXT_COLOR,
                       font=(FONT_FAMILY, MEDIUM_FONT_SIZE))
        style.map('TButton', 
                 background=[('active', ACCENT_COLOR), ('pressed', INFO_COLOR)],
                 foreground=[('active', DARK_BG), ('pressed', DARK_BG)])
        
        # Status bar style
        style.configure('Status.TLabel', background=LIGHT_BG, foreground=TEXT_COLOR,
                       font=(FONT_FAMILY, SMALL_FONT_SIZE), padding=5)
        
        # Header styles
        style.configure('Header.TLabel', font=(FONT_FAMILY, LARGE_FONT_SIZE, 'bold'),
                       foreground=ACCENT_COLOR, background=DARK_BG, padding=10)
        
        # Card styles (for metric display panels)
        style.configure('Card.TFrame', background=LIGHT_BG, relief='raised', borderwidth=1)
        style.configure('Card.TLabel', background=LIGHT_BG, foreground=TEXT_COLOR)
        style.configure('CardTitle.TLabel', background=LIGHT_BG, foreground=ACCENT_COLOR,
                       font=(FONT_FAMILY, MEDIUM_FONT_SIZE, 'bold'), padding=(0, 5))
        
        # Value display styles
        style.configure('Value.TLabel', background=LIGHT_BG, foreground=TEXT_COLOR,
                       font=(FONT_FAMILY, LARGE_FONT_SIZE, 'bold'))
        
        # Success/Warning/Error styles
        style.configure('Success.TLabel', foreground=SUCCESS_COLOR)
        style.configure('Warning.TLabel', foreground=WARNING_COLOR)
        style.configure('Error.TLabel', foreground=ALERT_COLOR)
        
        # Progressbar
        style.configure('TProgressbar', background=ACCENT_COLOR, troughcolor=LIGHT_BG,
                       borderwidth=0, thickness=20)
        
        # Treeview (for devices list)
        style.configure('Treeview', 
                       background=LIGHT_BG, 
                       foreground=TEXT_COLOR,
                       fieldbackground=LIGHT_BG,
                       borderwidth=0,
                       font=(FONT_FAMILY, MEDIUM_FONT_SIZE))
        style.configure('Treeview.Heading', 
                       background=DARK_BG, 
                       foreground=ACCENT_COLOR,
                       font=(FONT_FAMILY, MEDIUM_FONT_SIZE, 'bold'))
        style.map('Treeview', 
                 background=[('selected', INFO_COLOR)],
                 foreground=[('selected', TEXT_COLOR)])
        
        # Combobox
        style.configure('TCombobox', 
                       background=LIGHT_BG, 
                       foreground=DARK_BG,
                       fieldbackground=LIGHT_BG,
                       selectbackground=ACCENT_COLOR,
                       selectforeground=DARK_BG)
        style.map('TCombobox', 
                 fieldbackground=[('readonly', LIGHT_BG)],
                 selectbackground=[('readonly', ACCENT_COLOR)])
    
    def _create_layout(self):
        """Create the main layout for the application."""
        # Create main container with padding
        main_frame = ttk.Frame(self.root, style='TFrame', padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create header
        self._create_header(main_frame)
        
        # Create content area with two columns
        content_frame = ttk.Frame(main_frame, style='TFrame')
        content_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        content_frame.columnconfigure(0, weight=1)
        content_frame.columnconfigure(1, weight=1)
        
        # Left column
        left_frame = ttk.Frame(content_frame, style='TFrame')
        left_frame.grid(row=0, column=0, sticky='nsew', padx=(0, 5))
        
        # Signal strength panel
        self._create_signal_panel(left_frame)
        
        # Speed test panel
        self._create_speed_panel(left_frame)
        
        # Right column
        right_frame = ttk.Frame(content_frame, style='TFrame')
        right_frame.grid(row=0, column=1, sticky='nsew', padx=(5, 0))
        
        # Network usage panel
        self._create_network_usage_panel(right_frame)
        
        # Connected devices panel
        self._create_devices_panel(right_frame)
        
        # Settings panel
        self._create_settings_panel(right_frame)
        
        # Create menu bar
        self._create_menu_bar()
        
        # Status bar
        self._create_status_bar(main_frame)
    
    def _create_header(self, parent):
        """Create the header with interface selection."""
        header_frame = ttk.Frame(parent, style='TFrame')
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # App title
        title_label = ttk.Label(header_frame, text="WiFi Metrics Analyzer", 
                              style='Header.TLabel')
        title_label.pack(side=tk.LEFT)
        
        # Interface selection
        interface_frame = ttk.Frame(header_frame, style='TFrame')
        interface_frame.pack(side=tk.RIGHT)
        
        ttk.Label(interface_frame, text="Interface:", style='TLabel').pack(side=tk.LEFT)
        
        # Create combobox for interface selection
        interface_combo = ttk.Combobox(interface_frame, textvariable=self.selected_interface,
                                     values=self.analyzer.wifi_interfaces,
                                     state="readonly", width=10)
        interface_combo.pack(side=tk.LEFT, padx=5)
        interface_combo.bind('<<ComboboxSelected>>', self._on_interface_change)
        
        # Refresh interfaces button
        refresh_button = ttk.Button(interface_frame, text="↻", width=3,
                                  command=self._refresh_interfaces)
        refresh_button.pack(side=tk.LEFT)
        
        # Interface info
        info_frame = ttk.Frame(header_frame, style='TFrame')
        info_frame.pack(side=tk.RIGHT, padx=20)
        
        ttk.Label(info_frame, textvariable=self.essid_var, style='TLabel').pack(side=tk.RIGHT)
        ttk.Label(info_frame, text="Network: ", style='TLabel').pack(side=tk.RIGHT)
    
    def _create_signal_panel(self, parent):
        """Create the signal strength panel with gauge visualization."""
        signal_frame = ttk.Frame(parent, style='Card.TFrame')
        signal_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Panel title
        ttk.Label(signal_frame, text="Signal Strength", style='CardTitle.TLabel').pack(anchor=tk.W, padx=10)
        
        # Create matplotlib figure for gauge
        self.signal_fig = Figure(figsize=(5, 4), dpi=100, facecolor=LIGHT_BG)
        self.signal_ax = self.signal_fig.add_subplot(111, polar=True)
        
        # Initial gauge setup
        self.signal_ax.set_facecolor(LIGHT_BG)
        self.signal_ax.set_theta_zero_location('N')
        self.signal_ax.set_theta_direction(-1)
        self.signal_ax.set_rlabel_position(180)
        self.signal_ax.set_yticks([])
        self.signal_ax.set_xticks([])
        self.signal_ax.set_ylim(0, 10)
        
        # Create canvas for matplotlib figure
        self.signal_canvas = FigureCanvasTkAgg(self.signal_fig, master=signal_frame)
        self.signal_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Signal info panel
        info_frame = ttk.Frame(signal_frame, style='Card.TFrame', padding=10)
        info_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Signal strength
        ttk.Label(info_frame, text="Signal Strength:", style='Card.TLabel').grid(row=0, column=0, sticky=tk.W)
        ttk.Label(info_frame, textvariable=self.signal_strength_var, style='Value.TLabel').grid(row=0, column=1, sticky=tk.E)
        
        # Signal quality
        ttk.Label(info_frame, text="Signal Quality:", style='Card.TLabel').grid(row=1, column=0, sticky=tk.W)
        
        # Quality progressbar
        self.quality_progressbar = ttk.Progressbar(info_frame, style='TProgressbar', 
                                               orient=tk.HORIZONTAL, length=200, mode='determinate')
        self.quality_progressbar.grid(row=1, column=1, sticky=tk.E, pady=5)
        
        # Make grid columns expand properly
        info_frame.columnconfigure(1, weight=1)
        
        # Update gauge with initial data
        self._update_signal_gauge(0)
    
    def _create_speed_panel(self, parent):
        """Create the speed test panel."""
        speed_frame = ttk.Frame(parent, style='Card.TFrame')
        speed_frame.pack(fill=tk.BOTH, expand=True)
        
        # Panel title
        ttk.Label(speed_frame, text="Speed Test", style='CardTitle.TLabel').pack(anchor=tk.W, padx=10, pady=(10, 0))
        
        # Speed test info
        info_frame = ttk.Frame(speed_frame, style='Card.TFrame', padding=10)
        info_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Download speed
        ttk.Label(info_frame, text="Download:", style='Card.TLabel').grid(row=0, column=0, sticky=tk.W, pady=5)
        download_label = ttk.Label(info_frame, textvariable=self.download_speed_var, style='Value.TLabel')
        download_label.grid(row=0, column=1, sticky=tk.E)
        
        # Upload speed
        ttk.Label(info_frame, text="Upload:", style='Card.TLabel').grid(row=1, column=0, sticky=tk.W, pady=5)
        upload_label = ttk.Label(info_frame, textvariable=self.upload_speed_var, style='Value.TLabel')
        upload_label.grid(row=1, column=1, sticky=tk.E)
        
        # Ping
        ttk.Label(info_frame, text="Ping:", style='Card.TLabel').grid(row=2, column=0, sticky=tk.W, pady=5)
        ping_label = ttk.Label(info_frame, textvariable=self.ping_var, style='Value.TLabel')
        ping_label.grid(row=2, column=1, sticky=tk.E)
        
        # Make columns expand properly
        info_frame.columnconfigure(1, weight=1)
        
        # Button to run speed test
        button_frame = ttk.Frame(speed_frame, style='Card.TFrame')
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        self.speed_test_button = ttk.Button(button_frame, text="Run Speed Test", 
                                         command=self._run_speed_test)
        self.speed_test_button.pack(pady=10)
        
        # Progress indicator for speed test
        self.speed_test_progress = ttk.Progressbar(button_frame, mode='indeterminate')
        # Only pack when the test is running
    
    def _create_network_usage_panel(self, parent):
        """Create the network usage panel with real-time graph."""
        usage_frame = ttk.Frame(parent, style='Card.TFrame')
        usage_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Panel title
        ttk.Label(usage_frame, text="Network Usage", style='CardTitle.TLabel').pack(anchor=tk.W, padx=10)
        
        # Network usage graph
        self.network_fig = Figure(figsize=(5, 3), dpi=100, facecolor=LIGHT_BG)
        self.network_ax = self.network_fig.add_subplot(111)
        
        # Set background color and axis colors
        self.network_ax.set_facecolor(LIGHT_BG)
        self.network_ax.tick_params(axis='x', colors=TEXT_COLOR)
        self.network_ax.tick_params(axis='y', colors=TEXT_COLOR)
        self.network_ax.spines['bottom'].set_color(TEXT_COLOR)
        self.network_ax.spines['top'].set_color(TEXT_COLOR)
        self.network_ax.spines['left'].set_color(TEXT_COLOR)
        self.network_ax.spines['right'].set_color(TEXT_COLOR)
        self.network_ax.set_xlabel('Time', color=TEXT_COLOR)
        self.network_ax.set_ylabel('KB/s', color=TEXT_COLOR)
        self.network_ax.grid(True, linestyle='--', alpha=0.7)
        
        # Create empty data for initial plot
        x = np.arange(60)
        download_data = np.zeros(60)
        upload_data = np.zeros(60)
        
        # Create lines for download and upload speeds
        self.download_line, = self.network_ax.plot(x, download_data, label='Download', color=ACCENT_COLOR, linewidth=2)
        self.upload_line, = self.network_ax.plot(x, upload_data, label='Upload', color=WARNING_COLOR, linewidth=2)
        
        # Add legend
        self.network_ax.legend(loc='upper right', facecolor=LIGHT_BG, edgecolor=TEXT_COLOR, labelcolor=TEXT_COLOR)
        
        # Create canvas for matplotlib figure
        self.network_canvas = FigureCanvasTkAgg(self.network_fig, master=usage_frame)
        self.network_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Current usage display
        usage_info_frame = ttk.Frame(usage_frame, style='Card.TFrame', padding=10)
        usage_info_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(usage_info_frame, text="Current Usage:", style='Card.TLabel').pack(side=tk.LEFT)
        ttk.Label(usage_info_frame, textvariable=self.network_usage_var, style='Value.TLabel').pack(side=tk.RIGHT)
    
    def _create_devices_panel(self, parent):
        """Create the connected devices panel."""
        devices_frame = ttk.Frame(parent, style='Card.TFrame')
        devices_frame.pack(fill=tk.BOTH, expand=True)
        
        # Panel title and count
        title_frame = ttk.Frame(devices_frame, style='Card.TFrame')
        title_frame.pack(fill=tk.X)
        
        ttk.Label(title_frame, text="Connected Devices", style='CardTitle.TLabel').pack(side=tk.LEFT, padx=10)
        
        device_count_frame = ttk.Frame(title_frame, style='Card.TFrame')
        device_count_frame.pack(side=tk.RIGHT, padx=10)
        
        ttk.Label(device_count_frame, text="Devices: ", style='Card.TLabel').pack(side=tk.LEFT)
        ttk.Label(device_count_frame, textvariable=self.devices_count_var, style='Value.TLabel').pack(side=tk.LEFT)
        
        # Create treeview for devices
        columns = ('ip', 'mac')
        self.devices_tree = ttk.Treeview(devices_frame, columns=columns, show='headings', style='Treeview')
        
        # Define headings
        self.devices_tree.heading('ip', text='IP Address')
        self.devices_tree.heading('mac', text='MAC Address')
        
        # Define columns
        self.devices_tree.column('ip', width=150, anchor=tk.W)
        self.devices_tree.column('mac', width=150, anchor=tk.W)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(devices_frame, orient=tk.VERTICAL, command=self.devices_tree.yview)
        self.devices_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack widgets
        self.devices_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=10, padx=(0, 10))
        
        # Button to scan for devices
        button_frame = ttk.Frame(devices_frame, style='Card.TFrame')
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        self.scan_button = ttk.Button(button_frame, text="Scan for Devices", 
                                    command=self._scan_for_devices)
        self.scan_button.pack(pady=10)
        
        # Progress indicator for scanning
        self.scan_progress = ttk.Progressbar(button_frame, mode='indeterminate')
        # Only pack when scanning is running
    
    def _create_status_bar(self, parent):
        """Create the status bar at the bottom of the window."""
        status_frame = ttk.Frame(parent, style='TFrame')
        status_frame.pack(fill=tk.X, side=tk.BOTTOM)
        
        # Status message on the left
        self.status_label = ttk.Label(status_frame, textvariable=self.status_var, style='Status.TLabel')
        self.status_label.pack(side=tk.LEFT)
        
        # Interface info on the right
        self.interface_label = ttk.Label(status_frame, textvariable=self.interface_var, style='Status.TLabel')
        self.interface_label.pack(side=tk.RIGHT)
        
        # Add a separator
        separator = ttk.Separator(parent, orient=tk.HORIZONTAL)
        separator.pack(fill=tk.X, side=tk.BOTTOM, pady=(0, 5))
    
    def _refresh_interfaces(self):
        """Refresh the list of WiFi interfaces."""
        try:
            self.analyzer.update_wifi_interfaces()
            # Update interface dropdown
            interfaces = self.analyzer.wifi_interfaces
            
            if not interfaces:
                self.status_var.set("No WiFi interfaces found")
                return
            
            # Update the combobox values
            combo = self.root.nametowidget(self.root.winfo_children()[0].winfo_children()[0].winfo_children()[2].winfo_children()[1])
            combo['values'] = interfaces
            
            # If the current selection is no longer available, select the first interface
            if self.selected_interface.get() not in interfaces:
                if interfaces:
                    self.selected_interface.set(interfaces[0])
                    self._on_interface_change(None)
                else:
                    self.selected_interface.set("")
            
            self.status_var.set(f"Found {len(interfaces)} WiFi interfaces")
            
        except Exception as e:
            logger.error(f"Error refreshing interfaces: {e}")
            self.status_var.set(f"Error refreshing interfaces: {str(e)}")
    
    def _on_interface_change(self, event):
        """Handle interface selection change."""
        interface = self.selected_interface.get()
        if interface:
            self.interface_var.set(f"Interface: {interface}")
            self.status_var.set(f"Selected interface: {interface}")
            
            # Update metrics for the selected interface
            self._update_metrics(force=True)
    
    def _start_metrics_update(self):
        """Start the periodic metrics update."""
        if not self.update_running:
            self.update_running = True
            self._update_metrics()
            
            # Schedule the animation for signal gauge and network graph
            self.signal_anim = animation.FuncAnimation(
                self.signal_fig, self._animate_signal, interval=1000, blit=False)
            self.network_anim = animation.FuncAnimation(
                self.network_fig, self._animate_network, interval=1000, blit=False)
    
    def _update_metrics(self, force=False):
        """Update all metrics from the analyzer."""
        try:
            interface = self.selected_interface.get()
            if not interface:
                return
            
            # Update signal strength
            signal_info = self.analyzer.get_signal_strength(interface)
            if signal_info:
                essid = signal_info.get('essid', 'Not connected')
                self.essid_var.set(essid)
                
                signal_level = signal_info.get('signal_level_dbm')
                if signal_level is not None:
                    self.signal_strength_var.set(f"{signal_level} dBm")
                else:
                    self.signal_strength_var.set("N/A")
                
                signal_quality = signal_info.get('signal_quality')
                if signal_quality is not None:
                    quality_str = f"{signal_quality:.1f}%"
                    self.signal_quality_var.set(quality_str)
                    
                    # Update progressbar
                    self.quality_progressbar['value'] = signal_quality
                    
                    # Add to history for graph
                    current_time = datetime.datetime.now().strftime('%H:%M:%S')
                    self.signal_history.append(signal_quality)
                    self.time_labels.append(current_time)
                    
                    # Track connection stability
                    self.connection_history.append({
                        'time': time.time(),
                        'connected': signal_info.get('connected', False),
                        'quality': signal_quality,
                        'signal_level': signal_level
                    })
                    
                    # Check for notifications
                    self._check_signal_notifications(signal_quality, essid)
                    
                else:
                    self.signal_quality_var.set("0%")
                    self.quality_progressbar['value'] = 0
            
            # Update network usage
            current_stats = self.analyzer.get_network_usage(interface)
            current_time = time.time()
            
            if current_stats and self.last_network_stats:
                # Calculate rates in KB/s
                time_diff = current_time - self.last_network_time
                if time_diff > 0:
                    bytes_recv_diff = current_stats.get('bytes_recv', 0) - self.last_network_stats.get('bytes_recv', 0)
                    bytes_sent_diff = current_stats.get('bytes_sent', 0) - self.last_network_stats.get('bytes_sent', 0)
                    
                    recv_rate = bytes_recv_diff / time_diff / 1024  # KB/s
                    sent_rate = bytes_sent_diff / time_diff / 1024  # KB/s
                    
                    # Format rates
                    if recv_rate >= 1024:
                        recv_str = f"{recv_rate/1024:.2f} MB/s"
                    else:
                        recv_str = f"{recv_rate:.2f} KB/s"
                        
                    if sent_rate >= 1024:
                        sent_str = f"{sent_rate/1024:.2f} MB/s"
                    else:
                        sent_str = f"{sent_rate:.2f} KB/s"
                    
                    self.network_usage_var.set(f"↓ {recv_str}  ↑ {sent_str}")
                    
                    # Add to history for graph (store in KB/s)
                    self.network_history.append((recv_rate, sent_rate))
            
            self.last_network_stats = current_stats
            self.last_network_time = current_time
            
            # Schedule next update if still running
            if self.update_running:
                self.root.after(1000, self._update_metrics)
                
        except Exception as e:
            logger.error(f"Error updating metrics: {e}")
            self.status_var.set(f"Error updating metrics: {str(e)}")
            
            # Try again later
            if self.update_running:
                self.root.after(5000, self._update_metrics)
    
    def _update_signal_gauge(self, quality):
        """Update the signal strength gauge with the given quality percentage."""
        self.signal_ax.clear()
        
        # Configure gauge appearance
        self.signal_ax.set_facecolor(LIGHT_BG)
        self.signal_ax.set_theta_zero_location('N')
        self.signal_ax.set_theta_direction(-1)
        self.signal_ax.set_rlabel_position(180)
        
        # Set gauge range from 0 to 100%
        # Using a semi-circle (pi radians)
        theta = np.linspace(0, np.pi, 100)
        r = np.ones(100) * 9
        
        # Draw the background arc
        self.signal_ax.plot(theta, r, color='gray', alpha=0.3, linewidth=15)
        
        # Calculate the angle based on quality
        if quality > 0:
            quality_angle = np.pi * (quality / 100)
            quality_theta = np.linspace(0, quality_angle, int(quality))
            quality_r = np.ones(int(quality)) * 9
            
            # Determine color based on quality
            if quality >= 70:
                color = SUCCESS_COLOR
            elif quality >= 30:
                color = WARNING_COLOR
            else:
                color = ALERT_COLOR
                
            # Draw the quality arc
            if len(quality_theta) > 0:
                self.signal_ax.plot(quality_theta, quality_r, color=color, linewidth=15)
        
        # Add labels
        self.signal_ax.text(-0.05, 0, '0%', transform=self.signal_ax.transAxes, 
                         fontsize=12, color=TEXT_COLOR, horizontalalignment='right')
        self.signal_ax.text(1.05, 0, '100%', transform=self.signal_ax.transAxes, 
                         fontsize=12, color=TEXT_COLOR, horizontalalignment='left')
        
        # Add the quality value in the center
        self.signal_ax.text(0.5, 0.25, f'{quality:.1f}%', transform=self.signal_ax.transAxes,
                         fontsize=18, color=TEXT_COLOR, horizontalalignment='center',
                         verticalalignment='center')
        
        # Hide axes
        self.signal_ax.set_yticks([])
        self.signal_ax.set_xticks([])
        self.signal_ax.set_ylim(0, 10)
        
        # Refresh the canvas
        self.signal_canvas.draw()
    
    def _animate_signal(self, i):
        """Animation function for the signal gauge."""
        if self.signal_history:
            quality = self.signal_history[-1]
            self._update_signal_gauge(quality)
    
    def _animate_network(self, i):
        """Animation function for the network usage graph."""
        if len(self.network_history) < 2:
            return
        
        # Clear previous plot
        self.network_ax.clear()
        
        # Prepare data
        download_data = [x[0] for x in self.network_history]
        upload_data = [x[1] for x in self.network_history]
        x = np.arange(len(download_data))
        
        # Plot new data
        self.network_ax.plot(x, download_data, label='Download', color=ACCENT_COLOR, linewidth=2)
        self.network_ax.plot(x, upload_data, label='Upload', color=WARNING_COLOR, linewidth=2)
        
        # Set style
        self.network_ax.set_facecolor(LIGHT_BG)
        self.network_ax.tick_params(axis='x', colors=TEXT_COLOR, labelsize=8)
        self.network_ax.tick_params(axis='y', colors=TEXT_COLOR)
        self.network_ax.spines['bottom'].set_color(TEXT_COLOR)
        self.network_ax.spines['top'].set_color(TEXT_COLOR)
        self.network_ax.spines['left'].set_color(TEXT_COLOR)
        self.network_ax.spines['right'].set_color(TEXT_COLOR)
        self.network_ax.set_xlabel('Time', color=TEXT_COLOR)
        self.network_ax.set_ylabel('KB/s', color=TEXT_COLOR)
        self.network_ax.grid(True, linestyle='--', alpha=0.7)
        
        # Add legend
        self.network_ax.legend(loc='upper right', facecolor=LIGHT_BG, edgecolor=TEXT_COLOR, labelcolor=TEXT_COLOR)
        
        # Add time labels every 10 seconds
        if len(self.time_labels) > 10:
            indices = np.linspace(0, len(self.time_labels)-1, 6, dtype=int)
            self.network_ax.set_xticks(indices)
            self.network_ax.set_xticklabels([self.time_labels[i] for i in indices], rotation=45)
        
        # Refresh the canvas
        self.network_canvas.draw()
    
    def _run_speed_test(self):
        """Run a speed test and update the UI."""
        if self.speed_test_running:
            return
        
        self.speed_test_running = True
        self.speed_test_button.configure(state='disabled')
        
        # Show progress bar
        self.speed_test_progress.pack(fill=tk.X, padx=10, pady=(0, 10))
        self.speed_test_progress.start(10)
        
        self.status_var.set("Running speed test...")
        
        def update_callback(data):
            """Callback function for speed test progress updates."""
            status = data.get('status')
            message = data.get('message', '')
            
            if status == 'complete':
                results = data.get('results', {})
                download = results.get('download', 0)
                upload = results.get('upload', 0)
                ping = results.get('ping', 0)
                
                # Update UI with results
                if download > 0:
                    if download >= 1000:
                        self.download_speed_var.set(f"{download/1000:.2f} Gbps")
                    else:
                        self.download_speed_var.set(f"{download:.2f} Mbps")
                
                if upload > 0:
                    if upload >= 1000:
                        self.upload_speed_var.set(f"{upload/1000:.2f} Gbps")
                    else:
                        self.upload_speed_var.set(f"{upload:.2f} Mbps")
                
                if ping > 0:
                    self.ping_var.set(f"{ping:.1f} ms")
                
                # Clean up
                self.speed_test_progress.stop()
                self.speed_test_progress.pack_forget()
                self.speed_test_button.configure(state='normal')
                self.speed_test_running = False
                self.status_var.set("Speed test completed")
                
            elif status == 'error':
                # Handle error
                self.status_var.set(f"Speed test error: {message}")
                messagebox.showerror("Speed Test Error", message)
                
                # Clean up
                self.speed_test_progress.stop()
                self.speed_test_progress.pack_forget()
                self.speed_test_button.configure(state='normal')
                self.speed_test_running = False
                
            else:
                # Update status
                self.status_var.set(message)
        
        # Run the speed test in the analyzer
        interface = self.selected_interface.get()
        self.analyzer.run_speed_test(callback=update_callback)
    
    def _scan_for_devices(self):
        """Scan for connected devices and update the UI."""
        if self.scanning_devices:
            return
        
        self.scanning_devices = True
        self.scan_button.configure(state='disabled')
        
        # Show progress bar
        self.scan_progress.pack(fill=tk.X, padx=10, pady=(0, 10))
        self.scan_progress.start(10)
        
        self.status_var.set("Scanning for connected devices...")
        
        def scan_thread():
            """Thread function for scanning devices."""
            try:
                interface = self.selected_interface.get()
                devices = self.analyzer.get_connected_devices(interface)
                
                # Update UI in the main thread
                self.root.after(0, lambda: self._update_devices_list(devices))
                
            except Exception as e:
                logger.error(f"Error scanning for devices: {e}")
                # Update UI in the main thread
                self.root.after(0, lambda: self._handle_scan_error(str(e)))
        
        # Run in a separate thread to avoid blocking the UI
        threading.Thread(target=scan_thread, daemon=True).start()
    
    def _update_devices_list(self, devices):
        """Update the devices list with scan results."""
        # Clear existing items
        for item in self.devices_tree.get_children():
            self.devices_tree.delete(item)
        
        # Add new devices
        for device in devices:
            self.devices_tree.insert('', tk.END, values=(device.get('ip', ''), device.get('mac', '')))
        
        # Update device count
        self.devices_count_var.set(str(len(devices)))
        
        # Clean up
        self.scan_progress.stop()
        self.scan_progress.pack_forget()
        self.scan_button.configure(state='normal')
        self.scanning_devices = False
        
        self.status_var.set(f"Found {len(devices)} devices on the network")
    
    def _handle_scan_error(self, error_message):
        """Handle errors during device scanning."""
        messagebox.showerror("Scan Error", f"Error scanning for devices: {error_message}")
        
        # Clean up
        self.scan_progress.stop()
        self.scan_progress.pack_forget()
        self.scan_button.configure(state='normal')
        self.scanning_devices = False
        
        self.status_var.set(f"Error scanning for devices: {error_message}")
    
    def _check_signal_notifications(self, signal_quality, network_name):
        """Check if signal notifications should be sent."""
        if not self.notifications_enabled or not NOTIFICATIONS_AVAILABLE:
            return
            
        current_time = time.time()
        
        # Check cooldown period
        if current_time - self.last_notification_time < self.notification_cooldown:
            return
            
        notification_sent = False
        
        # Critical signal strength
        if signal_quality < self.signal_threshold_critical:
            self._send_notification(
                "Critical WiFi Signal",
                f"Signal strength very low ({signal_quality:.1f}%) on {network_name}. Consider moving closer to router or switching networks.",
                urgency="critical"
            )
            notification_sent = True
            
        # Low signal strength warning
        elif signal_quality < self.signal_threshold_low:
            self._send_notification(
                "Weak WiFi Signal",
                f"Signal strength is low ({signal_quality:.1f}%) on {network_name}. Network performance may be affected.",
                urgency="normal"
            )
            notification_sent = True
            
        # Check connection stability (if we have enough history)
        if len(self.connection_history) >= 10:
            recent_disconnections = sum(1 for entry in list(self.connection_history)[-10:] 
                                      if not entry.get('connected', True))
            
            if recent_disconnections >= 3:
                self._send_notification(
                    "Unstable WiFi Connection",
                    f"Frequent disconnections detected on {network_name}. Check your network settings.",
                    urgency="normal"
                )
                notification_sent = True
        
        if notification_sent:
            self.last_notification_time = current_time
    
    def _send_notification(self, title, message, urgency="normal"):
        """Send a desktop notification."""
        try:
            if NOTIFICATIONS_AVAILABLE:
                plyer.notification.notify(
                    title=title,
                    message=message,
                    app_name="WiFi Metrics Analyzer",
                    timeout=10
                )
                logger.info(f"Notification sent: {title} - {message}")
            else:
                # Fallback: use system notification if plyer is not available
                if platform.system() == "Linux":
                    subprocess.run([
                        "notify-send", 
                        "-u", urgency, 
                        "-t", "10000",
                        title, 
                        message
                    ], check=False, capture_output=True)
                elif platform.system() == "Windows":
                    # Windows toast notification (requires Windows 10+)
                    subprocess.run([
                        "powershell", 
                        "-Command", 
                        f"New-BurntToastNotification -Text '{title}', '{message}'"
                    ], check=False, capture_output=True)
                elif platform.system() == "Darwin":  # macOS
                    subprocess.run([
                        "osascript", 
                        "-e", 
                        f'display notification "{message}" with title "{title}"'
                    ], check=False, capture_output=True)
                    
        except Exception as e:
            logger.warning(f"Failed to send notification: {e}")
    
    def _create_settings_panel(self, parent):
        """Create a settings panel for notifications and thresholds."""
        settings_frame = ttk.Frame(parent, style='Card.TFrame')
        settings_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Panel title
        ttk.Label(settings_frame, text="Settings", style='CardTitle.TLabel').pack(anchor=tk.W, padx=10)
        
        # Settings content
        content_frame = ttk.Frame(settings_frame, style='Card.TFrame', padding=10)
        content_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Notifications toggle
        self.notifications_var = tk.BooleanVar(value=self.notifications_enabled)
        notifications_check = ttk.Checkbutton(
            content_frame, 
            text="Enable desktop notifications", 
            variable=self.notifications_var,
            command=self._toggle_notifications
        )
        notifications_check.grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=2)
        
        # Signal thresholds
        ttk.Label(content_frame, text="Low signal threshold:", style='Card.TLabel').grid(row=1, column=0, sticky=tk.W, pady=2)
        
        self.low_threshold_var = tk.IntVar(value=self.signal_threshold_low)
        low_threshold_spin = ttk.Spinbox(
            content_frame,
            from_=10,
            to=80,
            width=10,
            textvariable=self.low_threshold_var,
            command=self._update_thresholds
        )
        low_threshold_spin.grid(row=1, column=1, sticky=tk.E, pady=2)
        
        ttk.Label(content_frame, text="Critical signal threshold:", style='Card.TLabel').grid(row=2, column=0, sticky=tk.W, pady=2)
        
        self.critical_threshold_var = tk.IntVar(value=self.signal_threshold_critical)
        critical_threshold_spin = ttk.Spinbox(
            content_frame,
            from_=5,
            to=50,
            width=10,
            textvariable=self.critical_threshold_var,
            command=self._update_thresholds
        )
        critical_threshold_spin.grid(row=2, column=1, sticky=tk.E, pady=2)
        
        # Auto-refresh interval
        ttk.Label(content_frame, text="Refresh interval (seconds):", style='Card.TLabel').grid(row=3, column=0, sticky=tk.W, pady=2)
        
        self.refresh_interval_var = tk.IntVar(value=1)
        refresh_interval_spin = ttk.Spinbox(
            content_frame,
            from_=1,
            to=60,
            width=10,
            textvariable=self.refresh_interval_var
        )
        refresh_interval_spin.grid(row=3, column=1, sticky=tk.E, pady=2)
        
        content_frame.columnconfigure(1, weight=1)
    
    def _toggle_notifications(self):
        """Toggle desktop notifications on/off."""
        self.notifications_enabled = self.notifications_var.get()
        status = "enabled" if self.notifications_enabled else "disabled"
        self.status_var.set(f"Desktop notifications {status}")
        
        if self.notifications_enabled and not NOTIFICATIONS_AVAILABLE:
            messagebox.showwarning(
                "Notifications Unavailable", 
                "Desktop notifications are not available. Install 'plyer' package for full notification support."
            )
    
    def _update_thresholds(self):
        """Update signal strength thresholds."""
        self.signal_threshold_low = self.low_threshold_var.get()
        self.signal_threshold_critical = self.critical_threshold_var.get()
        
        # Ensure critical threshold is lower than low threshold
        if self.signal_threshold_critical >= self.signal_threshold_low:
            self.signal_threshold_critical = max(5, self.signal_threshold_low - 10)
            self.critical_threshold_var.set(self.signal_threshold_critical)
        
        self.status_var.set(f"Thresholds updated: Low={self.signal_threshold_low}%, Critical={self.signal_threshold_critical}%")
    
    def _create_menu_bar(self):
        """Create the application menu bar with advanced features."""
        menubar = tk.Menu(self.root, bg=DARK_BG, fg=TEXT_COLOR)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0, bg=LIGHT_BG, fg=TEXT_COLOR, activebackground=ACCENT_COLOR)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Export Report...", command=self._export_report)
        file_menu.add_command(label="Export Data...", command=self._export_data)
        file_menu.add_separator()
        file_menu.add_command(label="Settings", command=self._show_settings_dialog)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        # View menu
        view_menu = tk.Menu(menubar, tearoff=0, bg=LIGHT_BG, fg=TEXT_COLOR, activebackground=ACCENT_COLOR)
        menubar.add_cascade(label="View", menu=view_menu)
        view_menu.add_command(label="Full Screen", command=self._toggle_fullscreen)
        view_menu.add_command(label="Always on Top", command=self._toggle_always_on_top)
        view_menu.add_separator()
        view_menu.add_command(label="Refresh All", command=self._refresh_all_data)
        
        # Tools menu
        tools_menu = tk.Menu(menubar, tearoff=0, bg=LIGHT_BG, fg=TEXT_COLOR, activebackground=ACCENT_COLOR)
        menubar.add_cascade(label="Tools", menu=tools_menu)
        tools_menu.add_command(label="Network Diagnostics", command=self._run_network_diagnostics)
        tools_menu.add_command(label="Connection Test", command=self._test_connection)
        tools_menu.add_command(label="WiFi Signal History", command=self._show_signal_history)
        tools_menu.add_separator()
        tools_menu.add_command(label="Reset All Data", command=self._reset_all_data)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0, bg=LIGHT_BG, fg=TEXT_COLOR, activebackground=ACCENT_COLOR)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="User Guide", command=self._show_user_guide)
        help_menu.add_command(label="Keyboard Shortcuts", command=self._show_shortcuts)
        help_menu.add_separator()
        help_menu.add_command(label="About", command=self._show_about_dialog)
        
        # Bind keyboard shortcuts
        self.root.bind('<F5>', lambda e: self._refresh_all_data())
        self.root.bind('<F11>', lambda e: self._toggle_fullscreen())
        self.root.bind('<Control-q>', lambda e: self.root.quit())
        self.root.bind('<Control-r>', lambda e: self._refresh_all_data())
        self.root.bind('<Control-s>', lambda e: self._show_settings_dialog())
    
    def _export_report(self):
        """Export a comprehensive WiFi metrics report."""
        try:
            from tkinter import filedialog
            import json
            from datetime import datetime
            
            # Get current interface
            interface = self.selected_interface.get()
            if not interface:
                messagebox.showwarning("Export Error", "No interface selected")
                return
            
            # Choose file location
            filename = filedialog.asksaveasfilename(
                defaultextension=".json",
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
                title="Export WiFi Report"
            )
            
            if not filename:
                return
            
            # Gather all current metrics
            signal_info = self.analyzer.get_signal_strength(interface)
            network_usage = self.analyzer.get_network_usage(interface)
            interface_info = self.analyzer.get_interface_info(interface)
            
            # Create comprehensive report
            report = {
                "report_info": {
                    "generated_at": datetime.now().isoformat(),
                    "interface": interface,
                    "application": "WiFi Metrics Analyzer v2.0"
                },
                "signal_metrics": signal_info,
                "network_usage": network_usage,
                "interface_info": interface_info,
                "speed_test_results": self.analyzer.speed_test_results,
                "connected_devices": self.analyzer.connected_devices,
                "signal_history": list(self.signal_history),
                "connection_stability": {
                    "total_measurements": len(self.connection_history),
                    "disconnections": sum(1 for entry in self.connection_history if not entry.get('connected', True)),
                    "average_signal_quality": sum(entry.get('quality', 0) for entry in self.connection_history) / max(len(self.connection_history), 1)
                },
                "notification_settings": {
                    "enabled": self.notifications_enabled,
                    "low_threshold": self.signal_threshold_low,
                    "critical_threshold": self.signal_threshold_critical
                }
            }
            
            # Write report to file
            with open(filename, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            self.status_var.set(f"Report exported to {filename}")
            messagebox.showinfo("Export Successful", f"WiFi metrics report exported to:\n{filename}")
            
        except Exception as e:
            logger.error(f"Error exporting report: {e}")
            messagebox.showerror("Export Error", f"Failed to export report:\n{str(e)}")
    
    def _export_data(self):
        """Export raw data in CSV format."""
        try:
            from tkinter import filedialog
            import csv
            from datetime import datetime
            
            # Choose file location
            filename = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
                title="Export WiFi Data"
            )
            
            if not filename:
                return
            
            # Write CSV data
            with open(filename, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                
                # Write headers
                writer.writerow(['Timestamp', 'Signal_Quality', 'Signal_Level_dBm', 'Connected', 'Network_Download_KB', 'Network_Upload_KB'])
                
                # Write connection history data
                for i, entry in enumerate(self.connection_history):
                    timestamp = datetime.fromtimestamp(entry.get('time', time.time())).isoformat()
                    signal_quality = entry.get('quality', 0)
                    signal_level = entry.get('signal_level', 0)
                    connected = entry.get('connected', False)
                    
                    # Get corresponding network data if available
                    download_kb = upload_kb = 0
                    if i < len(self.network_history):
                        download_kb, upload_kb = self.network_history[i]
                    
                    writer.writerow([timestamp, signal_quality, signal_level, connected, download_kb, upload_kb])
            
            self.status_var.set(f"Data exported to {filename}")
            messagebox.showinfo("Export Successful", f"WiFi data exported to:\n{filename}")
            
        except Exception as e:
            logger.error(f"Error exporting data: {e}")
            messagebox.showerror("Export Error", f"Failed to export data:\n{str(e)}")
    
    def _show_settings_dialog(self):
        """Show an advanced settings dialog."""
        settings_window = tk.Toplevel(self.root)
        settings_window.title("WiFi Analyzer Settings")
        settings_window.geometry("400x500")
        settings_window.configure(bg=DARK_BG)
        settings_window.transient(self.root)
        settings_window.grab_set()
        
        # Create notebook for tabbed settings
        notebook = ttk.Notebook(settings_window)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Notifications tab
        notif_frame = ttk.Frame(notebook, style='Card.TFrame')
        notebook.add(notif_frame, text="Notifications")
        
        # Monitoring tab
        monitor_frame = ttk.Frame(notebook, style='Card.TFrame')
        notebook.add(monitor_frame, text="Monitoring")
        
        # Advanced tab
        advanced_frame = ttk.Frame(notebook, style='Card.TFrame')
        notebook.add(advanced_frame, text="Advanced")
        
        # Populate notification settings
        self._create_notification_settings(notif_frame)
        self._create_monitoring_settings(monitor_frame)
        self._create_advanced_settings(advanced_frame)
        
        # Buttons
        button_frame = ttk.Frame(settings_window, style='TFrame')
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Button(button_frame, text="Apply", command=lambda: self._apply_settings(settings_window)).pack(side=tk.RIGHT, padx=5)
        ttk.Button(button_frame, text="Cancel", command=settings_window.destroy).pack(side=tk.RIGHT)
    
    def _create_notification_settings(self, parent):
        """Create notification settings in the settings dialog."""
        ttk.Label(parent, text="Desktop Notifications", style='CardTitle.TLabel').pack(anchor=tk.W, padx=10, pady=10)
        
        content = ttk.Frame(parent, style='Card.TFrame', padding=10)
        content.pack(fill=tk.BOTH, expand=True, padx=10)
        
        # Enable notifications checkbox
        self.settings_notifications_var = tk.BooleanVar(value=self.notifications_enabled)
        ttk.Checkbutton(content, text="Enable desktop notifications", variable=self.settings_notifications_var).pack(anchor=tk.W, pady=5)
        
        # Thresholds
        ttk.Label(content, text="Signal Quality Thresholds:", style='Card.TLabel').pack(anchor=tk.W, pady=(10, 5))
        
        threshold_frame = ttk.Frame(content, style='Card.TFrame')
        threshold_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(threshold_frame, text="Low signal warning (%)").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.settings_low_threshold = tk.IntVar(value=self.signal_threshold_low)
        ttk.Spinbox(threshold_frame, from_=10, to=80, textvariable=self.settings_low_threshold, width=10).grid(row=0, column=1, sticky=tk.E, pady=2)
        
        ttk.Label(threshold_frame, text="Critical signal alert (%)").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.settings_critical_threshold = tk.IntVar(value=self.signal_threshold_critical)
        ttk.Spinbox(threshold_frame, from_=5, to=50, textvariable=self.settings_critical_threshold, width=10).grid(row=1, column=1, sticky=tk.E, pady=2)
        
        threshold_frame.columnconfigure(1, weight=1)
    
    def _create_monitoring_settings(self, parent):
        """Create monitoring settings in the settings dialog."""
        ttk.Label(parent, text="Monitoring Configuration", style='CardTitle.TLabel').pack(anchor=tk.W, padx=10, pady=10)
        
        content = ttk.Frame(parent, style='Card.TFrame', padding=10)
        content.pack(fill=tk.BOTH, expand=True, padx=10)
        
        # Refresh intervals
        ttk.Label(content, text="Update intervals:", style='Card.TLabel').pack(anchor=tk.W, pady=(0, 5))
        
        interval_frame = ttk.Frame(content, style='Card.TFrame')
        interval_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(interval_frame, text="Metrics refresh (seconds)").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.settings_refresh_interval = tk.IntVar(value=1)
        ttk.Spinbox(interval_frame, from_=1, to=60, textvariable=self.settings_refresh_interval, width=10).grid(row=0, column=1, sticky=tk.E, pady=2)
        
        # History settings
        ttk.Label(content, text="Data History:", style='Card.TLabel').pack(anchor=tk.W, pady=(10, 5))
        
        history_frame = ttk.Frame(content, style='Card.TFrame')
        history_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(history_frame, text="Signal history points").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.settings_signal_history = tk.IntVar(value=60)
        ttk.Spinbox(history_frame, from_=30, to=300, textvariable=self.settings_signal_history, width=10).grid(row=0, column=1, sticky=tk.E, pady=2)
        
        interval_frame.columnconfigure(1, weight=1)
        history_frame.columnconfigure(1, weight=1)
    
    def _create_advanced_settings(self, parent):
        """Create advanced settings in the settings dialog."""
        ttk.Label(parent, text="Advanced Options", style='CardTitle.TLabel').pack(anchor=tk.W, padx=10, pady=10)
        
        content = ttk.Frame(parent, style='Card.TFrame', padding=10)
        content.pack(fill=tk.BOTH, expand=True, padx=10)
        
        # Auto-save settings
        self.settings_auto_save = tk.BooleanVar(value=True)
        ttk.Checkbutton(content, text="Auto-save configuration", variable=self.settings_auto_save).pack(anchor=tk.W, pady=5)
        
        # Debug mode
        self.settings_debug_mode = tk.BooleanVar(value=False)
        ttk.Checkbutton(content, text="Enable debug logging", variable=self.settings_debug_mode).pack(anchor=tk.W, pady=5)
        
        # Always on top
        self.settings_always_on_top = tk.BooleanVar(value=False)
        ttk.Checkbutton(content, text="Keep window always on top", variable=self.settings_always_on_top).pack(anchor=tk.W, pady=5)
    
    def _apply_settings(self, settings_window):
        """Apply settings from the settings dialog."""
        try:
            # Apply notification settings
            self.notifications_enabled = self.settings_notifications_var.get()
            self.signal_threshold_low = self.settings_low_threshold.get()
            self.signal_threshold_critical = self.settings_critical_threshold.get()
            
            # Apply monitoring settings
            # (refresh interval would require restarting the update timer)
            
            # Apply advanced settings
            if self.settings_always_on_top.get():
                self.root.attributes('-topmost', True)
            else:
                self.root.attributes('-topmost', False)
            
            if self.settings_debug_mode.get():
                logging.getLogger().setLevel(logging.DEBUG)
            else:
                logging.getLogger().setLevel(logging.INFO)
            
            self.status_var.set("Settings applied successfully")
            settings_window.destroy()
            
        except Exception as e:
            logger.error(f"Error applying settings: {e}")
            messagebox.showerror("Settings Error", f"Failed to apply settings:\n{str(e)}")
    
    def _toggle_fullscreen(self):
        """Toggle fullscreen mode."""
        current_state = self.root.attributes('-fullscreen')
        self.root.attributes('-fullscreen', not current_state)
        
        if not current_state:
            self.status_var.set("Entered fullscreen mode (F11 to exit)")
        else:
            self.status_var.set("Exited fullscreen mode")
    
    def _toggle_always_on_top(self):
        """Toggle always on top mode."""
        current_state = self.root.attributes('-topmost')
        self.root.attributes('-topmost', not current_state)
        
        if not current_state:
            self.status_var.set("Window set to always on top")
        else:
            self.status_var.set("Window no longer always on top")
    
    def _refresh_all_data(self):
        """Refresh all data and clear history."""
        try:
            # Refresh interfaces
            self._refresh_interfaces()
            
            # Force metric update
            self._update_metrics(force=True)
            
            # Clear and refresh devices
            if not self.scanning_devices:
                self._scan_for_devices()
            
            self.status_var.set("All data refreshed")
            
        except Exception as e:
            logger.error(f"Error refreshing data: {e}")
            self.status_var.set(f"Error refreshing data: {str(e)}")
    
    def _run_network_diagnostics(self):
        """Run comprehensive network diagnostics."""
        try:
            diag_window = tk.Toplevel(self.root)
            diag_window.title("Network Diagnostics")
            diag_window.geometry("600x400")
            diag_window.configure(bg=DARK_BG)
            
            # Create text widget for diagnostics output
            text_frame = ttk.Frame(diag_window, style='Card.TFrame')
            text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            diag_text = tk.Text(text_frame, bg=LIGHT_BG, fg=TEXT_COLOR, font=(FONT_FAMILY, SMALL_FONT_SIZE))
            scrollbar = ttk.Scrollbar(text_frame, orient=tk.VERTICAL, command=diag_text.yview)
            diag_text.configure(yscrollcommand=scrollbar.set)
            
            diag_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            
            # Run diagnostics in a separate thread
            def run_diagnostics():
                interface = self.selected_interface.get()
                
                diag_text.insert(tk.END, f"Network Diagnostics for {interface}\n")
                diag_text.insert(tk.END, "=" * 40 + "\n\n")
                
                # Test 1: Interface information
                diag_text.insert(tk.END, "1. Interface Information:\n")
                interface_info = self.analyzer.get_interface_info(interface)
                for key, value in interface_info.items():
                    diag_text.insert(tk.END, f"   {key}: {value}\n")
                diag_text.insert(tk.END, "\n")
                
                # Test 2: Signal strength
                diag_text.insert(tk.END, "2. Signal Strength:\n")
                signal_info = self.analyzer.get_signal_strength(interface)
                for key, value in signal_info.items():
                    diag_text.insert(tk.END, f"   {key}: {value}\n")
                diag_text.insert(tk.END, "\n")
                
                # Test 3: Connectivity tests
                diag_text.insert(tk.END, "3. Connectivity Tests:\n")
                
                # Ping test
                try:
                    result = subprocess.run(['ping', '-c', '4', '8.8.8.8'], 
                                          capture_output=True, text=True, timeout=30)
                    if result.returncode == 0:
                        diag_text.insert(tk.END, "   Internet connectivity: PASS\n")
                        # Extract ping times
                        lines = result.stdout.split('\n')
                        for line in lines:
                            if 'time=' in line:
                                diag_text.insert(tk.END, f"   {line.strip()}\n")
                    else:
                        diag_text.insert(tk.END, "   Internet connectivity: FAIL\n")
                        diag_text.insert(tk.END, f"   Error: {result.stderr}\n")
                except subprocess.TimeoutExpired:
                    diag_text.insert(tk.END, "   Internet connectivity: TIMEOUT\n")
                except Exception as e:
                    diag_text.insert(tk.END, f"   Internet connectivity: ERROR - {e}\n")
                
                diag_text.insert(tk.END, "\nDiagnostics complete.\n")
                diag_text.see(tk.END)
            
            threading.Thread(target=run_diagnostics, daemon=True).start()
            
        except Exception as e:
            logger.error(f"Error running diagnostics: {e}")
            messagebox.showerror("Diagnostics Error", f"Failed to run diagnostics:\n{str(e)}")
    
    def _test_connection(self):
        """Test internet connection speed and latency."""
        if not self.speed_test_running:
            self._run_speed_test()
        else:
            self.status_var.set("Speed test already running...")
    
    def _show_signal_history(self):
        """Show detailed signal history in a separate window."""
        try:
            history_window = tk.Toplevel(self.root)
            history_window.title("Signal Strength History")
            history_window.geometry("800x600")
            history_window.configure(bg=DARK_BG)
            
            # Create matplotlib figure for detailed history
            fig = Figure(figsize=(10, 6), dpi=100, facecolor=DARK_BG)
            ax = fig.add_subplot(111)
            
            # Plot signal history
            if self.signal_history:
                x = range(len(self.signal_history))
                ax.plot(x, list(self.signal_history), color=ACCENT_COLOR, linewidth=2)
                ax.fill_between(x, list(self.signal_history), alpha=0.3, color=ACCENT_COLOR)
                
                # Add threshold lines
                ax.axhline(y=self.signal_threshold_low, color=WARNING_COLOR, linestyle='--', alpha=0.7, label='Low Threshold')
                ax.axhline(y=self.signal_threshold_critical, color=ALERT_COLOR, linestyle='--', alpha=0.7, label='Critical Threshold')
            
            # Style the plot
            ax.set_facecolor(LIGHT_BG)
            ax.tick_params(axis='x', colors=TEXT_COLOR)
            ax.tick_params(axis='y', colors=TEXT_COLOR)
            ax.set_xlabel('Time', color=TEXT_COLOR)
            ax.set_ylabel('Signal Quality (%)', color=TEXT_COLOR)
            ax.set_title('WiFi Signal Strength History', color=TEXT_COLOR)
            ax.grid(True, alpha=0.3)
            ax.legend()
            
            # Create canvas
            canvas = FigureCanvasTkAgg(fig, master=history_window)
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
        except Exception as e:
            logger.error(f"Error showing signal history: {e}")
            messagebox.showerror("History Error", f"Failed to show signal history:\n{str(e)}")
    
    def _reset_all_data(self):
        """Reset all collected data and history."""
        result = messagebox.askyesno("Reset Data", "Are you sure you want to reset all collected data and history?")
        
        if result:
            try:
                # Clear all history
                self.signal_history.clear()
                self.network_history.clear()
                self.time_labels.clear()
                self.connection_history.clear()
                self.speed_history.clear()
                
                # Reset variables
                self.download_speed_var.set("N/A")
                self.upload_speed_var.set("N/A")
                self.ping_var.set("N/A")
                self.devices_count_var.set("0")
                
                # Clear devices tree
                for item in self.devices_tree.get_children():
                    self.devices_tree.delete(item)
                
                # Reset analyzer data
                self.analyzer.speed_test_results = {
                    'download': 0,
                    'upload': 0,
                    'ping': 0,
                    'timestamp': 0
                }
                self.analyzer.connected_devices = []
                
                self.status_var.set("All data reset successfully")
                
            except Exception as e:
                logger.error(f"Error resetting data: {e}")
                messagebox.showerror("Reset Error", f"Failed to reset data:\n{str(e)}")
    
    def _show_user_guide(self):
        """Show user guide and help information."""
        guide_window = tk.Toplevel(self.root)
        guide_window.title("WiFi Analyzer User Guide")
        guide_window.geometry("700x500")
        guide_window.configure(bg=DARK_BG)
        
        # Create notebook for different help sections
        notebook = ttk.Notebook(guide_window)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Overview tab
        overview_frame = ttk.Frame(notebook, style='Card.TFrame')
        notebook.add(overview_frame, text="Overview")
        
        overview_text = tk.Text(overview_frame, bg=LIGHT_BG, fg=TEXT_COLOR, font=(FONT_FAMILY, SMALL_FONT_SIZE), wrap=tk.WORD)
        overview_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        overview_content = """
WiFi Metrics Analyzer - User Guide

OVERVIEW:
This application provides comprehensive monitoring and analysis of your WiFi connection, including:

• Real-time signal strength monitoring with visual gauge
• Internet speed testing (download, upload, ping)
• Network usage tracking with live graphs
• Connected device discovery and listing
• Desktop notifications for connection issues
• Historical data tracking and analysis
• Network diagnostics and troubleshooting tools

FEATURES:

1. Signal Strength Panel:
   - Shows current signal strength in dBm
   - Visual quality gauge (0-100%)
   - Real-time updates every second
   - Color-coded quality indicators

2. Speed Test Panel:
   - On-demand internet speed testing
   - Download and upload speed measurement
   - Ping latency testing
   - Progress indication during tests

3. Network Usage Panel:
   - Real-time upload/download monitoring
   - Live graphs showing network activity
   - Current usage rate display
   - Historical usage tracking

4. Connected Devices Panel:
   - Scan for devices on your network
   - Display IP and MAC addresses
   - Device count tracking
   - Periodic scanning capabilities

5. Desktop Notifications:
   - Automatic alerts for weak signals
   - Connection stability monitoring
   - Configurable threshold settings
   - Cross-platform notification support
"""
        
        overview_text.insert(tk.END, overview_content)
        overview_text.config(state=tk.DISABLED)
        
        # Features tab
        features_frame = ttk.Frame(notebook, style='Card.TFrame')
        notebook.add(features_frame, text="Features")
        
        features_text = tk.Text(features_frame, bg=LIGHT_BG, fg=TEXT_COLOR, font=(FONT_FAMILY, SMALL_FONT_SIZE), wrap=tk.WORD)
        features_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        features_content = """
ADVANCED FEATURES:

• Export Functionality:
  - Export comprehensive reports in JSON format
  - Export raw data in CSV format for analysis
  - Include all metrics and historical data

• Customizable Settings:
  - Adjust notification thresholds
  - Configure monitoring intervals
  - Enable/disable specific features
  - Debug mode for troubleshooting

• Network Diagnostics:
  - Comprehensive network testing
  - Interface information analysis
  - Connectivity verification
  - Ping testing and latency analysis

• Interface Management:
  - Support for multiple WiFi interfaces
  - Easy interface switching
  - Automatic interface detection
  - Interface status monitoring

• Data Management:
  - Historical data preservation
  - Configurable history limits
  - Data reset capabilities
  - Auto-save functionality

TROUBLESHOoting:

• If no WiFi interfaces are detected:
  - Check that your WiFi adapter is enabled
  - Try running the application with sudo privileges
  - Verify that wireless drivers are installed

• For notification issues:
  - Install the 'plyer' package for full support
  - Check system notification settings
  - Verify notification permissions

• For scanning issues:
  - Run the application with elevated privileges
  - Check firewall settings
  - Ensure network discovery is enabled
"""
        
        features_text.insert(tk.END, features_content)
        features_text.config(state=tk.DISABLED)
    
    def _show_shortcuts(self):
        """Show keyboard shortcuts dialog."""
        shortcuts_window = tk.Toplevel(self.root)
        shortcuts_window.title("Keyboard Shortcuts")
        shortcuts_window.geometry("400x300")
        shortcuts_window.configure(bg=DARK_BG)
        shortcuts_window.transient(self.root)
        
        # Create shortcuts list
        frame = ttk.Frame(shortcuts_window, style='Card.TFrame', padding=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(frame, text="Keyboard Shortcuts", style='CardTitle.TLabel').pack(pady=(0, 20))
        
        shortcuts = [
            ("F5", "Refresh all data"),
            ("F11", "Toggle fullscreen"),
            ("Ctrl+Q", "Quit application"),
            ("Ctrl+R", "Refresh all data"),
            ("Ctrl+S", "Open settings")
        ]
        
        for key, description in shortcuts:
            shortcut_frame = ttk.Frame(frame, style='Card.TFrame')
            shortcut_frame.pack(fill=tk.X, pady=2)
            
            ttk.Label(shortcut_frame, text=key, style='Value.TLabel').pack(side=tk.LEFT)
            ttk.Label(shortcut_frame, text=description, style='Card.TLabel').pack(side=tk.RIGHT)
    
    def _show_about_dialog(self):
        """Show about dialog with application information."""
        about_text = """
WiFi Metrics Analyzer v2.0

A comprehensive WiFi monitoring and analysis tool

Features:
• Real-time signal strength monitoring
• Internet speed testing
• Network usage tracking
• Connected device discovery
• Desktop notifications
• Network diagnostics
• Data export capabilities

Developed for network administrators and power users
who need detailed WiFi connection insights.

Supports Linux, Windows, and macOS

Requires Python 3.7+ and appropriate system privileges
for full functionality.
"""
        
        messagebox.showinfo("About WiFi Metrics Analyzer", about_text)
    
    def run(self):
        """Run the application main loop."""
        try:
            self.root.mainloop()
        except Exception as e:
            logger.error(f"Error in main loop: {e}")
            messagebox.showerror("Application Error", f"An error occurred: {str(e)}")
        finally:
            # Clean up resources
            self.update_running = False

# Example usage
if __name__ == "__main__":
    try:
        # This would normally import the analyzer from wifi_analyzer.py
        # For testing, we'll create a mock
        class MockAnalyzer:
            def __init__(self):
                self.wifi_interfaces = ['wlan0', 'wlan1']
                
            def get_signal_strength(self, interface):
                return {
                    'essid': 'Test Network',
                    'signal_level_dbm': -65,
                    'signal_quality': 70,
                    'bit_rate': '54 Mb/s',
                    'frequency': 2.412
                }
                
            def get_network_usage(self, interface):
                return {
                    'bytes_sent': 1000000,
                    'bytes_recv': 5000000
                }
                
            def run_speed_test(self, callback=None):
                if callback:
                    callback({
                        'status': 'complete',
                        'message': 'Speed test complete',
                        'results': {
                            'download': 100,
                            'upload': 20,
                            'ping': 15,
                            'timestamp': time.time()
                        }
                    })
                return {
                    'download': 100,
                    'upload': 20,
                    'ping': 15,
                    'timestamp': time.time()
                }
                
            def get_connected_devices(self, interface):
                return [
                    {'ip': '192.168.1.1', 'mac': 'AA:BB:CC:DD:EE:FF'},
                    {'ip': '192.168.1.2', 'mac': '11:22:33:44:55:66'}
                ]
        
        # For actual usage, import the real analyzer
        from wifi_analyzer import WifiAnalyzer
        analyzer = WifiAnalyzer()
        
        # Create and run the GUI
        app = WifiAnalyzerGUI(analyzer)
        app.run()
        
    except ImportError:
        print("Running with mock analyzer for testing")
        analyzer = MockAnalyzer()
        app = WifiAnalyzerGUI(analyzer)
        app.run()
