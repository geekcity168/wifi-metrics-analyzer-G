#!/usr/bin/env python3
"""
WiFi Metrics Analyzer Module

This module provides functionality to analyze various WiFi metrics including
signal strength, speed, connected devices, and interface information.
Designed for Kali Linux environments.
"""

import re
import time
import subprocess
import threading
import logging
from typing import Dict, List, Tuple, Optional, Any, Union

import psutil
import speedtest
import netifaces
from scapy.all import ARP, Ether, srp

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('WifiAnalyzer')

class WifiAnalyzer:
    """
    A class to analyze WiFi metrics in a Kali Linux environment.
    
    This class provides methods to collect various WiFi metrics including
    signal strength, speed, connected devices, and interface information.
    
    Note: Some methods may require root/sudo privileges to function correctly.
    """
    
    def __init__(self):
        """Initialize the WiFi Analyzer with default settings."""
        self.wifi_interfaces = []
        self.update_wifi_interfaces()
        self.speed_test_results = {
            'download': 0,
            'upload': 0,
            'ping': 0,
            'timestamp': 0
        }
        self.connected_devices = []
        self.signal_strength = {}
        
        # Flag to indicate if we're running with sufficient privileges
        self._check_privileges()
    
    def _check_privileges(self) -> None:
        """
        Check if the script is running with sufficient privileges.
        Warns if not running as root for operations that might require it.
        """
        try:
            # In Linux, root has UID 0
            if psutil.Process().username() != 'root':
                logger.warning(
                    "Not running as root. Some operations like scanning for "
                    "connected devices may not work correctly. Consider running "
                    "with sudo for full functionality."
                )
                self.has_root = False
            else:
                self.has_root = True
        except Exception as e:
            logger.error(f"Error checking privileges: {e}")
            self.has_root = False
    
    def update_wifi_interfaces(self) -> List[str]:
        """
        Get a list of available WiFi interfaces.
        
        Returns:
            List[str]: List of WiFi interface names
        """
        try:
            # Get all network interfaces
            all_interfaces = netifaces.interfaces()
            
            # Filter for wireless interfaces (typically wlan0, wlan1, etc. in Linux)
            wifi_interfaces = [iface for iface in all_interfaces 
                              if iface.startswith(('wlan', 'wlp', 'wlx'))]
            
            # If no wireless interfaces found by naming convention, try checking with iwconfig
            if not wifi_interfaces:
                try:
                    # Run iwconfig to get wireless interfaces
                    result = subprocess.run(['iwconfig'], 
                                           capture_output=True, 
                                           text=True, 
                                           check=False)
                    
                    # Parse output to find interfaces with wireless extensions
                    for line in result.stdout.split('\n'):
                        if 'no wireless extensions' not in line and line.strip():
                            iface = line.split()[0]
                            if iface not in wifi_interfaces:
                                wifi_interfaces.append(iface)
                except (subprocess.SubprocessError, FileNotFoundError) as e:
                    logger.warning(f"Could not run iwconfig: {e}")
            
            self.wifi_interfaces = wifi_interfaces
            return wifi_interfaces
            
        except Exception as e:
            logger.error(f"Error getting WiFi interfaces: {e}")
            return []
    
    def get_interface_info(self, interface: str = None) -> Dict[str, Any]:
        """
        Get detailed information about a network interface.
        
        Args:
            interface (str, optional): Name of the interface. If None, uses the first WiFi interface.
            
        Returns:
            Dict[str, Any]: Dictionary containing interface information
        """
        if not interface:
            if not self.wifi_interfaces:
                self.update_wifi_interfaces()
            
            if not self.wifi_interfaces:
                logger.error("No WiFi interfaces available")
                return {}
            
            interface = self.wifi_interfaces[0]
        
        try:
            info = {
                'name': interface,
                'addresses': {},
                'status': 'unknown'
            }
            
            # Get interface addresses (IP, MAC, etc.)
            if interface in netifaces.interfaces():
                # Get IP addresses (IPv4 and IPv6)
                addresses = netifaces.ifaddresses(interface)
                
                # IPv4 addresses
                if netifaces.AF_INET in addresses:
                    info['addresses']['ipv4'] = [
                        {
                            'addr': addr.get('addr', ''),
                            'netmask': addr.get('netmask', ''),
                            'broadcast': addr.get('broadcast', '')
                        }
                        for addr in addresses[netifaces.AF_INET]
                    ]
                
                # IPv6 addresses
                if netifaces.AF_INET6 in addresses:
                    info['addresses']['ipv6'] = [
                        {
                            'addr': addr.get('addr', ''),
                            'netmask': addr.get('netmask', ''),
                        }
                        for addr in addresses[netifaces.AF_INET6]
                    ]
                
                # MAC address
                if netifaces.AF_LINK in addresses:
                    info['addresses']['mac'] = addresses[netifaces.AF_LINK][0].get('addr', '')
            
            # Check if interface is up
            try:
                with open(f"/sys/class/net/{interface}/operstate", 'r') as f:
                    state = f.read().strip()
                    info['status'] = state
            except (FileNotFoundError, PermissionError):
                # Try using ip link show as an alternative
                try:
                    result = subprocess.run(
                        ['ip', 'link', 'show', interface],
                        capture_output=True, text=True, check=False
                    )
                    if 'state UP' in result.stdout:
                        info['status'] = 'up'
                    elif 'state DOWN' in result.stdout:
                        info['status'] = 'down'
                except subprocess.SubprocessError:
                    pass
            
            return info
            
        except Exception as e:
            logger.error(f"Error getting interface info for {interface}: {e}")
            return {'name': interface, 'error': str(e)}
    
    def get_signal_strength(self, interface: str = None) -> Dict[str, Any]:
        """
        Get the WiFi signal strength for a specified interface.
        
        Args:
            interface (str, optional): Name of the interface. If None, uses the first WiFi interface.
            
        Returns:
            Dict[str, Any]: Dictionary containing signal strength and other wireless info
        """
        if not interface:
            if not self.wifi_interfaces:
                self.update_wifi_interfaces()
            
            if not self.wifi_interfaces:
                logger.error("No WiFi interfaces available")
                return {}
            
            interface = self.wifi_interfaces[0]
        
        try:
            # Run iwconfig to get signal information
            result = subprocess.run(
                ['iwconfig', interface], 
                capture_output=True, 
                text=True, 
                check=False
            )
            
            if result.returncode != 0:
                logger.error(f"Error running iwconfig: {result.stderr}")
                return {}
            
            output = result.stdout
            
            # Parse the output to extract signal strength and other info
            info = {
                'interface': interface,
                'connected': 'Not connected' not in output,
                'essid': None,
                'signal_level_dbm': None,
                'signal_quality': None,
                'bit_rate': None,
                'frequency': None
            }
            
            # Extract ESSID (network name)
            essid_match = re.search(r'ESSID:"([^"]*)"', output)
            if essid_match:
                info['essid'] = essid_match.group(1)
            
            # Extract signal level in dBm
            signal_match = re.search(r'Signal level=(-\d+) dBm', output)
            if signal_match:
                info['signal_level_dbm'] = int(signal_match.group(1))
                
                # Convert dBm to quality percentage (approximate)
                # -50 dBm or higher is excellent (100%), -100 dBm or lower is poor (0%)
                signal_dbm = info['signal_level_dbm']
                if signal_dbm >= -50:
                    quality = 100
                elif signal_dbm <= -100:
                    quality = 0
                else:
                    quality = 2 * (signal_dbm + 100)
                
                info['signal_quality'] = quality
            
            # Alternative format for signal quality
            quality_match = re.search(r'Link Quality=(\d+)/(\d+)', output)
            if quality_match and not info['signal_quality']:
                current, max_val = map(int, quality_match.groups())
                info['signal_quality'] = (current / max_val) * 100
            
            # Extract bit rate
            bit_rate_match = re.search(r'Bit Rate=([0-9.]+ [GMK]b/s)', output)
            if bit_rate_match:
                info['bit_rate'] = bit_rate_match.group(1)
            
            # Extract frequency
            freq_match = re.search(r'Frequency[=:]([\d.]+) GHz', output)
            if freq_match:
                info['frequency'] = float(freq_match.group(1))
            
            # Store the result
            self.signal_strength = info
            
            return info
            
        except Exception as e:
            logger.error(f"Error getting signal strength for {interface}: {e}")
            return {'interface': interface, 'error': str(e)}
    
    def run_speed_test(self, callback=None) -> Dict[str, Any]:
        """
        Run an internet speed test.
        
        Args:
            callback (callable, optional): A function to call with progress updates.
            
        Returns:
            Dict[str, Any]: Dictionary containing speed test results
        """
        def _run_test():
            try:
                logger.info("Starting speed test...")
                
                if callback:
                    callback({'status': 'starting', 'message': 'Starting speed test...'})
                
                # Create speedtest instance
                st = speedtest.Speedtest()
                
                # Get best server
                if callback:
                    callback({'status': 'finding_server', 'message': 'Finding best server...'})
                st.get_best_server()
                
                # Test download speed
                if callback:
                    callback({'status': 'download', 'message': 'Testing download speed...'})
                download_speed = st.download() / 1_000_000  # Convert to Mbps
                
                # Test upload speed
                if callback:
                    callback({'status': 'upload', 'message': 'Testing upload speed...'})
                upload_speed = st.upload() / 1_000_000  # Convert to Mbps
                
                # Get ping
                ping = st.results.ping
                
                # Store results
                self.speed_test_results = {
                    'download': download_speed,
                    'upload': upload_speed,
                    'ping': ping,
                    'timestamp': time.time()
                }
                
                if callback:
                    callback({
                        'status': 'complete',
                        'message': 'Speed test complete',
                        'results': self.speed_test_results
                    })
                
                logger.info(f"Speed test complete: {self.speed_test_results}")
                
            except Exception as e:
                error_msg = f"Error running speed test: {e}"
                logger.error(error_msg)
                
                if callback:
                    callback({
                        'status': 'error',
                        'message': error_msg
                    })
                
                self.speed_test_results = {
                    'download': 0,
                    'upload': 0,
                    'ping': 0,
                    'timestamp': time.time(),
                    'error': str(e)
                }
        
        # Run the speed test in a separate thread to avoid blocking
        thread = threading.Thread(target=_run_test)
        thread.daemon = True
        thread.start()
        
        return self.speed_test_results
    
    def get_connected_devices(self, interface: str = None, timeout: int = 2) -> List[Dict[str, str]]:
        """
        Scan for devices connected to the same network.
        
        Args:
            interface (str, optional): Name of the interface. If None, uses the first WiFi interface.
            timeout (int, optional): Timeout for ARP scan in seconds. Default is 2.
            
        Returns:
            List[Dict[str, str]]: List of dictionaries containing device info (IP and MAC addresses)
        """
        if not interface:
            if not self.wifi_interfaces:
                self.update_wifi_interfaces()
            
            if not self.wifi_interfaces:
                logger.error("No WiFi interfaces available")
                return []
            
            interface = self.wifi_interfaces[0]
        
        if not self.has_root:
            logger.warning(
                "Connected device scanning requires root privileges. "
                "Run with sudo for accurate results."
            )
        
        try:
            # Get interface information to determine the network
            interface_info = self.get_interface_info(interface)
            
            if not interface_info or 'addresses' not in interface_info:
                logger.error(f"Could not get network information for {interface}")
                return []
            
            # Get IP information
            if ('ipv4' not in interface_info['addresses'] or 
                not interface_info['addresses']['ipv4']):
                logger.error(f"No IPv4 address found for {interface}")
                return []
            
            # Get first IPv4 address
            ip_info = interface_info['addresses']['ipv4'][0]
            ip_addr = ip_info.get('addr', '')
            
            if not ip_addr:
                logger.error(f"No IP address found for {interface}")
                return []
            
            # Create network address for ARP scan (e.g., 192.168.1.0/24)
            # This is a simplified approach; in a real app, you'd calculate this from IP and netmask
            network = ip_addr.rsplit('.', 1)[0] + '.0/24'
            
            logger.info(f"Scanning network {network} on interface {interface}...")
            
            # Create ARP request packet
            arp = ARP(pdst=network)
            ether = Ether(dst="ff:ff:ff:ff:ff:ff")  # Broadcast
            packet = ether/arp
            
            # Send ARP request and get responses
            result = srp(packet, timeout=timeout, verbose=0, iface=interface)[0]
            
            # Process results
            devices = []
            for sent, received in result:
                devices.append({
                    'ip': received.psrc,
                    'mac': received.hwsrc
                })
            
            # Try to resolve vendor information based on MAC address
            # This would require a MAC vendor database, which is beyond the scope of this example
            
            self.connected_devices = devices
            return devices
            
        except Exception as e:
            logger.error(f"Error scanning for connected devices: {e}")
            return []
    
    def get_network_usage(self, interface: str = None) -> Dict[str, float]:
        """
        Get current network usage statistics for the specified interface.
        
        Args:
            interface (str, optional): Name of the interface. If None, uses the first WiFi interface.
            
        Returns:
            Dict[str, float]: Dictionary containing network usage statistics in bytes
        """
        if not interface:
            if not self.wifi_interfaces:
                self.update_wifi_interfaces()
            
            if not self.wifi_interfaces:
                logger.error("No WiFi interfaces available")
                return {}
            
            interface = self.wifi_interfaces[0]
        
        try:
            # Get network stats
            stats = psutil.net_io_counters(pernic=True).get(interface)
            
            if not stats:
                logger.error(f"No network statistics available for {interface}")
                return {}
            
            return {
                'bytes_sent': stats.bytes_sent,
                'bytes_recv': stats.bytes_recv,
                'packets_sent': stats.packets_sent,
                'packets_recv': stats.packets_recv,
                'errin': stats.errin,
                'errout': stats.errout,
                'dropin': stats.dropin,
                'dropout': stats.dropout
            }
            
        except Exception as e:
            logger.error(f"Error getting network usage for {interface}: {e}")
            return {}
    
    def get_all_metrics(self, interface: str = None) -> Dict[str, Any]:
        """
        Get all available WiFi metrics.
        
        Args:
            interface (str, optional): Name of the interface. If None, uses the first WiFi interface.
            
        Returns:
            Dict[str, Any]: Dictionary containing all WiFi metrics
        """
        if not interface:
            if not self.wifi_interfaces:
                self.update_wifi_interfaces()
            
            if not self.wifi_interfaces:
                logger.error("No WiFi interfaces available")
                return {}
            
            interface = self.wifi_interfaces[0]
        
        # Collect all metrics
        interface_info = self.get_interface_info(interface)
        signal_strength = self.get_signal_strength(interface)
        network_usage = self.get_network_usage(interface)
        
        # Don't run speed test as part of get_all_metrics since it takes time
        # Just return the latest results
        
        return {
            'interface': interface,
            'interface_info': interface_info,
            'signal_strength': signal_strength,
            'network_usage': network_usage,
            'speed_test': self.speed_test_results,
            'connected_devices': self.connected_devices,
            'timestamp': time.time()
        }

# Example usage
if __name__ == "__main__":
    analyzer = WifiAnalyzer()
    print(f"WiFi Interfaces: {analyzer.wifi_interfaces}")
    
    if analyzer.wifi_interfaces:
        interface = analyzer.wifi_interfaces[0]
        print(f"\nInterface Info ({interface}):")
        print(analyzer.get_interface_info(interface))
        
        print(f"\nSignal Strength ({interface}):")
        print(analyzer.get_signal_strength(interface))
        
        print(f"\nNetwork Usage ({interface}):")
        print(analyzer.get_network_usage(interface))
        
        print("\nRunning Speed Test (this may take a moment)...")
        analyzer.run_speed_test()
        # Wait for the speed test to complete
        time.sleep(20)
        print(f"Speed Test Results: {analyzer.speed_test_results}")
        
        print(f"\nScanning for Connected Devices ({interface}):")
        devices = analyzer.get_connected_devices(interface)
        for device in devices:
            print(f"IP: {device['ip']}, MAC: {device['mac']}")
