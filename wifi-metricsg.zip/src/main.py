#!/usr/bin/env python3
"""
WiFi Metrics Analyzer - Main Entry Point

This module serves as the main entry point for the WiFi Metrics Analyzer application.
It handles command-line arguments, initializes the analyzer, and launches the GUI.
"""

import os
import sys
import signal
import argparse
import logging
import subprocess
import threading
import time
from typing import Optional, List, Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(os.path.expanduser('~/.wifi-metrics-analyzer.log'))
    ]
)
logger = logging.getLogger('WifiMetricsAnalyzer')

# Import application modules
try:
    from wifi_analyzer import WifiAnalyzer
    from gui import WifiAnalyzerGUI
except ImportError as e:
    logger.critical(f"Failed to import required modules: {e}")
    logger.critical("Make sure you're running from the correct directory and all dependencies are installed")
    sys.exit(1)

def check_root_privileges() -> bool:
    """
    Check if the application is running with root privileges.
    
    Returns:
        bool: True if running as root, False otherwise
    """
    return os.geteuid() == 0

def run_with_sudo() -> None:
    """
    Restart the application with sudo privileges.
    """
    logger.info("Restarting with sudo privileges...")
    
    try:
        # Get the full path to the current script
        script_path = os.path.abspath(sys.argv[0])
        
        # Construct the command to run with sudo
        sudo_command = ['sudo', sys.executable, script_path] + sys.argv[1:]
        
        # Execute the command
        subprocess.run(sudo_command)
        sys.exit(0)
    except Exception as e:
        logger.error(f"Failed to restart with sudo: {e}")
        sys.exit(1)

def parse_arguments() -> argparse.Namespace:
    """
    Parse command-line arguments.
    
    Returns:
        argparse.Namespace: Parsed arguments
    """
    parser = argparse.ArgumentParser(
        description="WiFi Metrics Analyzer - Monitor WiFi signal strength, speed, and connected devices"
    )
    
    parser.add_argument(
        "-i", "--interface", 
        help="Specify the WiFi interface to use"
    )
    
    parser.add_argument(
        "--no-gui", 
        action="store_true",
        help="Run in command-line mode without GUI (not implemented yet)"
    )
    
    parser.add_argument(
        "--debug", 
        action="store_true",
        help="Enable debug logging"
    )
    
    parser.add_argument(
        "--force-root", 
        action="store_true",
        help="Force the application to run as root (sudo)"
    )
    
    parser.add_argument(
        "--version", 
        action="version",
        version="WiFi Metrics Analyzer v1.0.0"
    )
    
    return parser.parse_args()

def setup_signal_handlers(gui_app: Optional[WifiAnalyzerGUI] = None) -> None:
    """
    Set up signal handlers for clean shutdown.
    
    Args:
        gui_app: The GUI application instance for clean shutdown
    """
    def signal_handler(sig, frame):
        """Handle signals for clean shutdown."""
        logger.info(f"Received signal {sig}, shutting down...")
        if gui_app and hasattr(gui_app, 'root'):
            gui_app.update_running = False
            gui_app.root.quit()
        sys.exit(0)
    
    # Register signal handlers for clean shutdown
    signal.signal(signal.SIGINT, signal_handler)  # Ctrl+C
    signal.signal(signal.SIGTERM, signal_handler)  # Termination request

def create_assets_directory() -> None:
    """
    Create the assets directory for the application if it doesn't exist.
    """
    assets_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../assets')
    if not os.path.exists(assets_dir):
        try:
            os.makedirs(assets_dir)
            logger.debug(f"Created assets directory: {assets_dir}")
        except Exception as e:
            logger.warning(f"Failed to create assets directory: {e}")

def display_cli_info(analyzer: WifiAnalyzer, interface: str) -> None:
    """
    Display basic information in CLI mode.
    
    Args:
        analyzer: The WifiAnalyzer instance
        interface: The WiFi interface to use
    """
    print("\n======= WiFi Metrics Analyzer =======")
    print(f"Interface: {interface}")
    
    # Get signal strength
    signal_info = analyzer.get_signal_strength(interface)
    if signal_info:
        print(f"\nNetwork: {signal_info.get('essid', 'Not connected')}")
        print(f"Signal Strength: {signal_info.get('signal_level_dbm', 'N/A')} dBm")
        print(f"Signal Quality: {signal_info.get('signal_quality', 'N/A')}%")
        print(f"Bit Rate: {signal_info.get('bit_rate', 'N/A')}")
        print(f"Frequency: {signal_info.get('frequency', 'N/A')} GHz")
    
    # Get network usage
    usage = analyzer.get_network_usage(interface)
    if usage:
        print("\nNetwork Usage:")
        print(f"  Bytes Sent: {usage.get('bytes_sent', 0):,}")
        print(f"  Bytes Received: {usage.get('bytes_recv', 0):,}")
    
    print("\nFor full functionality, launch the GUI by running without --no-gui")
    print("======================================\n")

def main() -> None:
    """
    Main entry point for the application.
    """
    # Parse command-line arguments
    args = parse_arguments()
    
    # Set up logging level based on arguments
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
        logger.debug("Debug logging enabled")
    
    logger.info("Starting WiFi Metrics Analyzer")
    
    # Check for root privileges if required
    if args.force_root and not check_root_privileges():
        logger.warning("Root privileges requested but not running as root")
        run_with_sudo()
        return
    
    # Create assets directory
    create_assets_directory()
    
    try:
        # Initialize the WiFi analyzer
        logger.info("Initializing WiFi analyzer")
        analyzer = WifiAnalyzer()
        
        # Check if we found any WiFi interfaces
        if not analyzer.wifi_interfaces:
            logger.error("No WiFi interfaces found")
            print("Error: No WiFi interfaces found. Make sure your WiFi adapter is connected and enabled.")
            if not check_root_privileges():
                print("Note: Some operations require root privileges. Try running with sudo.")
            sys.exit(1)
        
        # Determine which interface to use
        interface = args.interface
        if not interface or interface not in analyzer.wifi_interfaces:
            # If specified interface is not valid, use the first available
            if interface and interface not in analyzer.wifi_interfaces:
                logger.warning(f"Specified interface '{interface}' not found")
            
            interface = analyzer.wifi_interfaces[0]
            logger.info(f"Using interface: {interface}")
        
        # Run in command-line mode if requested
        if args.no_gui:
            logger.info("Running in command-line mode")
            display_cli_info(analyzer, interface)
            return
        
        # Start the GUI
        logger.info("Initializing GUI")
        app = WifiAnalyzerGUI(analyzer)
        
        # Set up signal handlers for clean shutdown
        setup_signal_handlers(app)
        
        # If an interface was specified, select it
        if interface:
            app.selected_interface.set(interface)
            app._on_interface_change(None)
        
        # Run the application
        logger.info("Starting GUI main loop")
        app.run()
        
    except KeyboardInterrupt:
        logger.info("Application terminated by user")
    except Exception as e:
        logger.exception(f"Unhandled exception: {e}")
        print(f"\nError: {str(e)}")
        print("Check the log file for details: ~/.wifi-metrics-analyzer.log")
        sys.exit(1)
    finally:
        logger.info("Application shutdown complete")

if __name__ == "__main__":
    main()
