# Contributing to WiFi Metrics Analyzer

Thank you for your interest in contributing to WiFi Metrics Analyzer! This document provides guidelines for contributing to the project.

## 🚀 Quick Start

1. **Fork the Repository**
   ```bash
   git clone https://github.com/geekcity168/wifi-metrics-analyzer-G.git
   cd wifi-metrics-analyzer-G
   ```

2. **Set Up Development Environment**
   ```bash
   ./install.sh --minimal  # Minimal installation for development
   source venv/bin/activate
   ```

3. **Create a Feature Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

## 🤝 How to Contribute

### Reporting Issues
- **Bug Reports**: Use the bug report template
- **Feature Requests**: Use the feature request template
- **Security Issues**: Email directly to maintainers

### Pull Requests
1. **Before Starting**: Check existing issues and PRs
2. **Small Changes**: Submit directly
3. **Large Changes**: Open an issue for discussion first

### Code Standards

#### Python Code Style
- Follow **PEP 8** style guidelines
- Use **type hints** where appropriate
- Write **docstrings** for all functions and classes
- Maximum line length: **88 characters** (Black formatter)

#### Code Quality Tools
```bash
# Install development dependencies
pip install black flake8 mypy pytest

# Format code
black src/

# Check style
flake8 src/

# Type checking
mypy src/

# Run tests
pytest tests/
```

#### Documentation
- Update **README.md** for new features
- Include **docstrings** for all public functions
- Add **inline comments** for complex logic
- Update **CHANGELOG.md** for notable changes

## 📝 Development Guidelines

### File Structure
```
wifi-metrics-analyzer-G/
├── src/                    # Source code
│   ├── main.py            # Entry point
│   ├── gui.py             # GUI implementation
│   ├── wifi_analyzer.py   # Core analyzer logic
│   └── __init__.py        # Package initialization
├── tests/                 # Test files
├── assets/                # Icons and resources
├── docs/                  # Documentation
├── requirements.txt       # Python dependencies
├── install.sh            # Installation script
├── launch.sh             # Launcher script
└── README.md             # Project documentation
```

### Coding Conventions

#### Variable Naming
- **snake_case** for variables and functions
- **PascalCase** for classes
- **UPPER_CASE** for constants

#### Function Design
- **Single responsibility**: One function, one purpose
- **Pure functions**: Avoid side effects when possible
- **Error handling**: Use try/except blocks appropriately

#### GUI Development
- **Consistent styling**: Use defined color constants
- **Responsive design**: Test on different screen sizes
- **Accessibility**: Consider color contrast and keyboard navigation

### Testing

#### Test Categories
1. **Unit Tests**: Test individual functions
2. **Integration Tests**: Test component interactions
3. **GUI Tests**: Test user interface elements
4. **System Tests**: Test with real WiFi interfaces

#### Writing Tests
```python
import pytest
from src.wifi_analyzer import WifiAnalyzer

def test_wifi_analyzer_initialization():
    """Test WifiAnalyzer initializes correctly."""
    analyzer = WifiAnalyzer()
    assert isinstance(analyzer, WifiAnalyzer)
    assert hasattr(analyzer, 'wifi_interfaces')

def test_signal_strength_calculation():
    """Test signal strength quality calculation."""
    analyzer = WifiAnalyzer()
    # Add test implementation
```

#### Running Tests
```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=src

# Run specific test file
pytest tests/test_wifi_analyzer.py

# Run tests matching pattern
pytest -k "test_signal"
```

## 🐛 Issue Guidelines

### Bug Reports
Include:
- **OS and version** (Linux, Windows, macOS)
- **Python version**
- **WiFi adapter information**
- **Steps to reproduce**
- **Expected vs actual behavior**
- **Error messages/logs**
- **Screenshots** (for GUI issues)

### Feature Requests
Include:
- **Use case description**
- **Proposed solution**
- **Alternative solutions considered**
- **Additional context**

### Security Issues
- **Do not** create public issues for security vulnerabilities
- Email maintainers directly
- Include detailed reproduction steps
- Allow time for fix before disclosure

## 📋 Pull Request Process

### Before Submitting
1. **Update documentation** if needed
2. **Add tests** for new functionality
3. **Run all tests** and ensure they pass
4. **Check code style** with linting tools
5. **Update CHANGELOG.md** if applicable

### PR Description Template
```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update

## Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed

## Screenshots (if applicable)
Add screenshots to demonstrate changes

## Additional Notes
Any additional information for reviewers
```

### Review Process
1. **Automated checks** must pass (CI/CD)
2. **Code review** by maintainers
3. **Testing** on different platforms
4. **Documentation review**
5. **Merge** after approval

## 🌟 Areas for Contribution

### High Priority
- **Cross-platform compatibility** improvements
- **Performance optimizations**
- **Test coverage** expansion
- **Documentation** improvements
- **Accessibility** enhancements

### Feature Ideas
- **Mobile hotspot monitoring**
- **Network security analysis**
- **WiFi speed optimization suggestions**
- **Historical data analytics**
- **Custom notification rules**
- **Plugin system**
- **REST API for integration**

### Technical Improvements
- **Async/await** for better performance
- **Configuration management** system
- **Logging improvements**
- **Error handling** enhancements
- **Memory usage** optimization

## 💡 Tips for Contributors

### Getting Started
- **Start small**: Begin with documentation or small bug fixes
- **Ask questions**: Use GitHub Discussions for help
- **Read the code**: Understand existing patterns before contributing
- **Test thoroughly**: Ensure changes work across platforms

### Best Practices
- **Commit messages**: Use clear, descriptive commit messages
- **Branch naming**: Use descriptive branch names (feature/add-notifications)
- **Small PRs**: Keep pull requests focused and small
- **Documentation**: Update docs alongside code changes

### Communication
- **Be respectful**: Follow the code of conduct
- **Be patient**: Reviews take time
- **Be responsive**: Respond to feedback promptly
- **Be collaborative**: Work together to improve the project

## 📞 Getting Help

### Resources
- **GitHub Issues**: For bugs and feature requests
- **GitHub Discussions**: For questions and general discussion
- **Documentation**: Check README.md and inline docs
- **Code Examples**: Look at existing implementations

### Contact
- **Project Maintainer**: geekcity168
- **Repository**: https://github.com/geekcity168/wifi-metrics-analyzer-G
- **Issues**: https://github.com/geekcity168/wifi-metrics-analyzer-G/issues

## 🎉 Recognition

Contributors will be:
- **Listed** in CONTRIBUTORS.md
- **Mentioned** in release notes
- **Credited** in documentation

Thank you for contributing to WiFi Metrics Analyzer! 🚀

