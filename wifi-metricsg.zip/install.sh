#!/bin/bash

# WiFi Metrics Analyzer Installer Script
# Automated setup and installation

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Installation info
APP_NAME="WiFi Metrics Analyzer"
APP_VERSION="2.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DESKTOP_FILE="$HOME/.local/share/applications/wifi-analyzer.desktop"

echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                WiFi Metrics Analyzer v2.0                 ║${NC}"
echo -e "${CYAN}║                  Installation Script                      ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Function to print step
print_step() {
    echo -e "${BLUE}➤ $1${NC}"
}

# Function to print success
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Function to print error
print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Function to check if running as root
check_root() {
    if [ "$EUID" -eq 0 ]; then
        print_warning "Running as root. This will install system-wide."
        read -p "Continue? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo -e "${BLUE}Installation cancelled.${NC}"
            exit 1
        fi
    fi
}

# Function to check system requirements
check_system() {
    print_step "Checking system requirements..."
    
    # Check OS
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        print_success "Linux operating system detected"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        print_success "macOS operating system detected"
        print_warning "Some features may require additional setup on macOS"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        print_success "Windows operating system detected"
        print_warning "Some features may require additional setup on Windows"
    else
        print_warning "Unknown operating system: $OSTYPE"
    fi
    
    # Check Python
    if command -v python3 &> /dev/null; then
        local python_version=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
        local python_major=$(echo $python_version | cut -d. -f1)
        local python_minor=$(echo $python_version | cut -d. -f2)
        
        if [ "$python_major" -gt 3 ] || ([ "$python_major" -eq 3 ] && [ "$python_minor" -ge 7 ]); then
            print_success "Python $python_version (meets requirement: 3.7+)"
        else
            print_error "Python $python_version found, but version 3.7+ is required"
            exit 1
        fi
    else
        print_error "Python 3 not found. Please install Python 3.7 or later."
        echo -e "${YELLOW}Installation commands:${NC}"
        echo -e "  Ubuntu/Debian: ${CYAN}sudo apt update && sudo apt install python3 python3-venv python3-pip${NC}"
        echo -e "  Kali Linux:    ${CYAN}sudo apt install python3 python3-venv python3-pip${NC}"
        echo -e "  CentOS/RHEL:   ${CYAN}sudo yum install python3 python3-venv python3-pip${NC}"
        echo -e "  macOS:         ${CYAN}brew install python3${NC}"
        exit 1
    fi
    
    # Check if virtual environment module is available
    if python3 -m venv --help &> /dev/null; then
        print_success "Virtual environment support available"
    else
        print_error "Python venv module not found"
        echo -e "${YELLOW}Install with: ${CYAN}sudo apt install python3-venv${NC}"
        exit 1
    fi
}

# Function to install system dependencies
install_system_deps() {
    print_step "Installing system dependencies..."
    
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Detect package manager and install
        if command -v apt &> /dev/null; then
            print_step "Installing packages with apt..."
            sudo apt update
            sudo apt install -y wireless-tools net-tools iputils-ping python3-tk libnotify-bin
            print_success "System packages installed"
        elif command -v yum &> /dev/null; then
            print_step "Installing packages with yum..."
            sudo yum install -y wireless-tools net-tools iputils python3-tkinter libnotify
            print_success "System packages installed"
        elif command -v pacman &> /dev/null; then
            print_step "Installing packages with pacman..."
            sudo pacman -S --noconfirm wireless_tools net-tools iputils tk libnotify
            print_success "System packages installed"
        else
            print_warning "Unknown package manager. Please install manually:"
            echo -e "  - wireless-tools (for iwconfig)"
            echo -e "  - net-tools (for network utilities)"
            echo -e "  - iputils-ping (for ping)"
            echo -e "  - python3-tk (for GUI)"
            echo -e "  - libnotify (for notifications)"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        if command -v brew &> /dev/null; then
            print_step "Installing packages with Homebrew..."
            brew install tcl-tk
            print_success "macOS packages installed"
        else
            print_warning "Homebrew not found. Install from: https://brew.sh/"
        fi
    fi
}

# Function to create virtual environment
create_venv() {
    print_step "Creating virtual environment..."
    
    if [ -d "$SCRIPT_DIR/venv" ]; then
        print_warning "Virtual environment already exists. Removing..."
        rm -rf "$SCRIPT_DIR/venv"
    fi
    
    python3 -m venv "$SCRIPT_DIR/venv"
    if [ $? -eq 0 ]; then
        print_success "Virtual environment created"
    else
        print_error "Failed to create virtual environment"
        exit 1
    fi
}

# Function to install Python dependencies
install_python_deps() {
    print_step "Installing Python dependencies..."
    
    source "$SCRIPT_DIR/venv/bin/activate"
    
    # Upgrade pip first
    pip install --upgrade pip
    
    # Install requirements
    if [ -f "$SCRIPT_DIR/requirements.txt" ]; then
        pip install -r "$SCRIPT_DIR/requirements.txt"
        if [ $? -eq 0 ]; then
            print_success "Python dependencies installed"
        else
            print_error "Failed to install Python dependencies"
            exit 1
        fi
    else
        print_error "requirements.txt not found"
        exit 1
    fi
}

# Function to make scripts executable
make_executable() {
    print_step "Making scripts executable..."
    
    chmod +x "$SCRIPT_DIR/launch.sh"
    chmod +x "$SCRIPT_DIR/src/main.py"
    
    print_success "Scripts made executable"
}

# Function to install desktop entry
install_desktop_entry() {
    print_step "Installing desktop entry..."
    
    # Create applications directory if it doesn't exist
    mkdir -p "$(dirname "$DESKTOP_FILE")"
    
    # Update desktop file with correct paths
    sed "s|/home/geek168/Geek-Code/wifi-metricsg|$SCRIPT_DIR|g" "$SCRIPT_DIR/wifi-analyzer.desktop" > "$DESKTOP_FILE"
    chmod +x "$DESKTOP_FILE"
    
    # Update desktop database
    if command -v update-desktop-database &> /dev/null; then
        update-desktop-database "$HOME/.local/share/applications/"
    fi
    
    print_success "Desktop entry installed"
}

# Function to create symbolic link for global access
create_symlink() {
    print_step "Creating symbolic link for global access..."
    
    local bin_dir="$HOME/.local/bin"
    local symlink_path="$bin_dir/wifi-analyzer"
    
    # Create bin directory if it doesn't exist
    mkdir -p "$bin_dir"
    
    # Remove existing symlink if it exists
    if [ -L "$symlink_path" ]; then
        rm "$symlink_path"
    fi
    
    # Create new symlink
    ln -s "$SCRIPT_DIR/launch.sh" "$symlink_path"
    
    # Check if ~/.local/bin is in PATH
    if [[ ":$PATH:" != *":$bin_dir:"* ]]; then
        print_warning "~/.local/bin is not in your PATH"
        echo -e "${YELLOW}Add this line to your ~/.bashrc or ~/.zshrc:${NC}"
        echo -e "${CYAN}export PATH=\"\$HOME/.local/bin:\$PATH\"${NC}"
        echo ""
        echo -e "${YELLOW}Then reload your shell or run:${NC}"
        echo -e "${CYAN}source ~/.bashrc${NC}"
    fi
    
    print_success "Symbolic link created: $symlink_path"
}

# Function to run post-installation tests
run_tests() {
    print_step "Running post-installation tests..."
    
    # Test virtual environment
    if [ -f "$SCRIPT_DIR/venv/bin/activate" ]; then
        print_success "Virtual environment: OK"
    else
        print_error "Virtual environment: FAIL"
        return 1
    fi
    
    # Test Python dependencies
    source "$SCRIPT_DIR/venv/bin/activate"
    
    local deps=("psutil" "scapy" "netifaces" "matplotlib" "plyer" "numpy")
    for dep in "${deps[@]}"; do
        if python -c "import $dep" 2>/dev/null; then
            print_success "Dependency $dep: OK"
        else
            print_error "Dependency $dep: FAIL"
            return 1
        fi
    done
    
    # Test speedtest module (special case)
    if python -c "import speedtest" 2>/dev/null; then
        print_success "Dependency speedtest: OK"
    else
        print_error "Dependency speedtest: FAIL"
        return 1
    fi
    
    print_success "All tests passed"
}

# Function to show completion message
show_completion() {
    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                    Installation Complete!                 ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}🎉 WiFi Metrics Analyzer v2.0 has been successfully installed!${NC}"
    echo ""
    echo -e "${YELLOW}How to run:${NC}"
    echo -e "  1. ${CYAN}./launch.sh${NC}                     (from this directory)"
    echo -e "  2. ${CYAN}wifi-analyzer${NC}                   (if ~/.local/bin is in PATH)"
    echo -e "  3. ${CYAN}Search 'WiFi Metrics' in your applications menu${NC}"
    echo ""
    echo -e "${YELLOW}Quick start:${NC}"
    echo -e "  • ${CYAN}./launch.sh${NC}                     - Start with GUI"
    echo -e "  • ${CYAN}./launch.sh --cli${NC}               - Start in CLI mode"
    echo -e "  • ${CYAN}sudo ./launch.sh${NC}               - Start with full privileges"
    echo -e "  • ${CYAN}./launch.sh --help${NC}              - Show help"
    echo ""
    echo -e "${YELLOW}Features:${NC}"
    echo -e "  • Real-time WiFi signal monitoring"
    echo -e "  • Internet speed testing"
    echo -e "  • Network usage tracking"
    echo -e "  • Connected device discovery"
    echo -e "  • Desktop notifications"
    echo -e "  • Modern dark theme UI"
    echo -e "  • Data export capabilities"
    echo ""
    echo -e "${BLUE}For full functionality, run with sudo privileges!${NC}"
    echo ""
}

# Function to handle cleanup on failure
cleanup_on_failure() {
    print_error "Installation failed. Cleaning up..."
    
    # Remove virtual environment if it was created
    if [ -d "$SCRIPT_DIR/venv" ]; then
        rm -rf "$SCRIPT_DIR/venv"
        print_step "Removed virtual environment"
    fi
    
    # Remove desktop entry if it was created
    if [ -f "$DESKTOP_FILE" ]; then
        rm "$DESKTOP_FILE"
        print_step "Removed desktop entry"
    fi
    
    # Remove symlink if it was created
    if [ -L "$HOME/.local/bin/wifi-analyzer" ]; then
        rm "$HOME/.local/bin/wifi-analyzer"
        print_step "Removed symbolic link"
    fi
    
    echo -e "${RED}Installation aborted.${NC}"
    exit 1
}

# Function to show usage
show_usage() {
    echo -e "${BLUE}WiFi Metrics Analyzer Installer${NC}"
    echo ""
    echo -e "${YELLOW}Usage: $0 [OPTIONS]${NC}"
    echo ""
    echo -e "${YELLOW}Options:${NC}"
    echo -e "  --help              Show this help message"
    echo -e "  --no-system-deps    Skip system dependency installation"
    echo -e "  --no-desktop        Skip desktop integration"
    echo -e "  --minimal           Minimal installation (no system deps, no desktop)"
    echo ""
    echo -e "${YELLOW}Examples:${NC}"
    echo -e "  $0                  # Full installation"
    echo -e "  $0 --minimal        # Minimal installation"
    echo -e "  $0 --no-desktop     # Install without desktop integration"
}

# Main installation function
main() {
    local install_system_deps=true
    local install_desktop=true
    
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            --help|-h)
                show_usage
                exit 0
                ;;
            --no-system-deps)
                install_system_deps=false
                shift
                ;;
            --no-desktop)
                install_desktop=false
                shift
                ;;
            --minimal)
                install_system_deps=false
                install_desktop=false
                shift
                ;;
            *)
                echo -e "${RED}Unknown option: $1${NC}"
                show_usage
                exit 1
                ;;
        esac
    done
    
    # Set up error handling
    trap cleanup_on_failure ERR
    
    # Run installation steps
    check_root
    check_system
    
    if [ "$install_system_deps" = true ]; then
        install_system_deps
    else
        print_warning "Skipping system dependency installation"
    fi
    
    create_venv
    install_python_deps
    make_executable
    
    if [ "$install_desktop" = true ]; then
        install_desktop_entry
        create_symlink
    else
        print_warning "Skipping desktop integration"
    fi
    
    run_tests
    show_completion
}

# Handle Ctrl+C gracefully
trap 'echo -e "\n${YELLOW}⚠️  Installation interrupted by user${NC}"; cleanup_on_failure' INT

# Run main function
main "$@"

